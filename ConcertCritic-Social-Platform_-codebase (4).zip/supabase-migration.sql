-- Migration: Create profiles table with RLS policies and triggers
-- Description: Creates a user profiles table with proper indexing, RLS, and auto-updating timestamps

-- Create profiles table
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    bio TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance optimization
CREATE INDEX idx_profiles_user_id ON profiles(user_id);
CREATE INDEX idx_profiles_username ON profiles(username);

-- Enable Row Level Security (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Allow users to read all profiles
CREATE POLICY "Allow public read access" ON profiles
    FOR SELECT
    USING (true);

-- RLS Policy: Allow users to insert their own profile
CREATE POLICY "Allow users to insert own profile" ON profiles
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- RLS Policy: Allow users to update their own profile
CREATE POLICY "Allow users to update own profile" ON profiles
    FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- RLS Policy: Allow users to delete their own profile
CREATE POLICY "Allow users to delete own profile" ON profiles
    FOR DELETE
    USING (auth.uid() = user_id);

-- Create function to automatically update the updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to call the update function before any update
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Add helpful comments to the table and columns
COMMENT ON TABLE profiles IS 'User profile information linked to auth.users';
COMMENT ON COLUMN profiles.id IS 'Primary key for the profile';
COMMENT ON COLUMN profiles.user_id IS 'Foreign key reference to auth.users table';
COMMENT ON COLUMN profiles.username IS 'Unique username chosen by the user';
COMMENT ON COLUMN profiles.bio IS 'Optional user biography text';
COMMENT ON COLUMN profiles.avatar_url IS 'Optional URL to user avatar image';
COMMENT ON COLUMN profiles.created_at IS 'Timestamp when profile was created';
COMMENT ON COLUMN profiles.updated_at IS 'Timestamp when profile was last updated (auto-updated)';