-- Migration: Add location field to profiles and configure avatar storage
-- Description: This migration adds a location field to the profiles table and sets up
-- a secure storage bucket for user avatars with proper RLS policies and file restrictions.
-- Created: [Current Date]

BEGIN;

-- =============================================================================
-- SECTION 1: ALTER PROFILES TABLE
-- =============================================================================

-- Add location field to profiles table
-- This field stores the user's location information (city, country, etc.)
-- It's nullable to allow users to keep this information private if desired
ALTER TABLE profiles 
ADD COLUMN location TEXT;

-- Add comment to document the location field purpose
COMMENT ON COLUMN profiles.location IS 'User location information (city, country, etc.). Optional field that users can populate in their profile.';

-- =============================================================================
-- SECTION 2: CREATE AVATARS STORAGE BUCKET
-- =============================================================================

-- Create the avatars storage bucket for user profile pictures
-- This bucket will store user avatar images with public read access
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'avatars',
  'avatars', 
  true,  -- Public bucket for reading avatar images
  5242880,  -- 5MB file size limit (5 * 1024 * 1024 bytes)
  ARRAY[
    'image/jpeg',
    'image/jpg', 
    'image/png',
    'image/webp',
    'image/gif'
  ]  -- Only allow common image formats
)
ON CONFLICT (id) DO NOTHING;  -- Prevent errors if bucket already exists

-- Add comment to document the avatars bucket purpose
COMMENT ON TABLE storage.buckets IS 'Storage buckets configuration. The avatars bucket stores user profile pictures with 5MB limit and image-only restrictions.';

-- =============================================================================
-- SECTION 3: STORAGE RLS POLICIES FOR AVATARS BUCKET
-- =============================================================================

-- Policy 1: Allow authenticated users to upload their own avatars
-- Users can only upload files to paths that start with their user ID
-- This ensures users can only manage their own avatar files
CREATE POLICY "Users can upload their own avatars"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
  AND array_length(regexp_split_to_array(name, '/'), 1) = 2  -- Ensure proper folder structure: user_id/filename
);

-- Policy 2: Allow public read access to all avatar images
-- This enables avatar images to be displayed publicly across the application
-- without requiring authentication for viewing
CREATE POLICY "Public read access for avatars"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'avatars');

-- Policy 3: Allow users to update their own avatar files
-- Users can update/replace existing avatar files in their own folder
CREATE POLICY "Users can update their own avatars"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'avatars'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy 4: Allow users to delete their own avatar files
-- Users can remove their avatar files when no longer needed
CREATE POLICY "Users can delete their own avatars"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'avatars'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- =============================================================================
-- SECTION 4: ADDITIONAL STORAGE CONFIGURATION
-- =============================================================================

-- Create a function to generate standardized avatar filenames
-- Format: user_id/avatar-timestamp.extension
-- This helps prevent naming conflicts and organizes files properly
CREATE OR REPLACE FUNCTION generate_avatar_filename(user_id UUID, file_extension TEXT)
RETURNS TEXT
LANGUAGE plpgsql
AS $$
BEGIN
  -- Validate file extension is an allowed image format
  IF file_extension NOT IN ('jpg', 'jpeg', 'png', 'webp', 'gif') THEN
    RAISE EXCEPTION 'Invalid file extension. Only jpg, jpeg, png, webp, gif are allowed.';
  END IF;
  
  -- Return standardized filename with timestamp
  RETURN user_id::text || '/avatar-' || extract(epoch from now())::bigint || '.' || lower(file_extension);
END;
$$;

-- Add comment to document the filename generation function
COMMENT ON FUNCTION generate_avatar_filename(UUID, TEXT) IS 'Generates standardized filenames for avatar uploads in format: user_id/avatar-timestamp.extension. Validates file extensions against allowed image formats.';

-- Create a function to validate avatar upload requirements
-- This function can be used in application logic to ensure proper file handling
CREATE OR REPLACE FUNCTION validate_avatar_upload(
  file_size BIGINT,
  mime_type TEXT,
  user_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
BEGIN
  -- Check file size (5MB limit)
  IF file_size > 5242880 THEN
    RAISE EXCEPTION 'File size exceeds 5MB limit';
  END IF;
  
  -- Check MIME type
  IF mime_type NOT IN ('image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif') THEN
    RAISE EXCEPTION 'Invalid file type. Only JPEG, PNG, WebP, and GIF images are allowed.';
  END IF;
  
  -- Check user is authenticated (user_id is not null)
  IF user_id IS NULL THEN
    RAISE EXCEPTION 'User must be authenticated to upload avatars';
  END IF;
  
  RETURN TRUE;
END;
$$;

-- Add comment to document the validation function
COMMENT ON FUNCTION validate_avatar_upload(BIGINT, TEXT, UUID) IS 'Validates avatar upload requirements including file size (5MB max), MIME type (images only), and user authentication. Returns true if valid or raises exception.';

-- =============================================================================
-- SECTION 5: EXAMPLE USAGE AND DOCUMENTATION
-- =============================================================================

/*
USAGE EXAMPLES:

1. Generate avatar filename:
   SELECT generate_avatar_filename('123e4567-e89b-12d3-a456-426614174000'::uuid, 'jpg');
   -- Returns: '123e4567-e89b-12d3-a456-426614174000/avatar-1704067200.jpg'

2. Validate avatar upload:
   SELECT validate_avatar_upload(2048576, 'image/jpeg', auth.uid());
   -- Returns: true (if file is 2MB JPEG and user is authenticated)

3. Upload avatar via Supabase client (JavaScript example):
   const { data, error } = await supabase.storage
     .from('avatars')
     .upload(`${user.id}/avatar-${Date.now()}.jpg`, file, {
       upsert: true,
       contentType: 'image/jpeg'
     });
   4. Get public avatar URL:
   const { data } = supabase.storage
     .from('avatars')
     .getPublicUrl(`${user.id}/avatar-${timestamp}.jpg`);
   FOLDER STRUCTURE:
- avatars/
  ├── user-id-1/
  │   ├── avatar-1704067200.jpg
  │   └── avatar-1704067300.png
  └── user-id-2/
      └── avatar-1704067400.webp

SECURITY FEATURES:
- File size limited to 5MB maximum
- Only image MIME types allowed (JPEG, PNG, WebP, GIF)
- Users can only access their own folder (user_id/)
- Public read access for displaying avatars
- Authenticated upload/update/delete operations only
- Standardized naming prevents conflicts
- RLS policies enforce access control at database level
*/

COMMIT;