-- Migration: Make username column optional in profiles table
-- Created: 2024-01-XX
-- Description: Removes NOT NULL constraint from username column while maintaining UNIQUE constraint
-- and adding validation rules for username format and minimum length

BEGIN;

-- Remove the NOT NULL constraint from the username column
ALTER TABLE profiles 
ALTER COLUMN username DROP NOT NULL;

-- Add check constraint to ensure username is at least 3 characters when provided
ALTER TABLE profiles 
ADD CONSTRAINT check_username_min_length 
CHECK (username IS NULL OR length(username) >= 3);

-- Add check constraint to ensure username only contains letters, numbers, and underscores when provided
ALTER TABLE profiles 
ADD CONSTRAINT check_username_format 
CHECK (username IS NULL OR username ~ '^[a-zA-Z0-9_]+$');

-- Add comment to document the change
COMMENT ON COLUMN profiles.username IS 'Optional unique username for user profile. Must be at least 3 characters and contain only letters, numbers, and underscores when provided.';

COMMIT;