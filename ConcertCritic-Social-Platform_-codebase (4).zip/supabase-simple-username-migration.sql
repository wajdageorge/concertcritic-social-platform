-- Migration: Simplify profiles table with username-based identification
-- This migration removes the complex user_id foreign key dependency and 
-- uses auth.uid() directly for authorization, making the system more robust

BEGIN;

-- Drop the existing profiles table completely
-- This removes all foreign key constraints and dependencies
DROP TABLE IF EXISTS public.profiles CASCADE;

-- Create the new simplified profiles table
-- Uses username as the primary identifier instead of user_id foreign key
CREATE TABLE public.profiles (
    -- Primary key: auto-generated UUID
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Email: derived from auth.users.email for user identification
    -- This allows us to link profiles to users without foreign key constraints
    email TEXT NOT NULL,
    
    -- Username: optional but unique identifier for public profiles
    -- Nullable allows users to remain anonymous until they choose a username
    username VARCHAR(50) UNIQUE,
    
    -- Bio: optional profile description
    bio TEXT,
    
    -- Location: optional location field (was missing from original schema)
    location TEXT,
    
    -- Avatar URL: optional profile image
    avatar_url TEXT,
    
    -- Timestamps: automatic creation and update tracking
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create indexes for performance
-- Email index for fast user lookups (most common query pattern)
CREATE INDEX profiles_email_idx ON public.profiles(email);

-- Username index for public profile lookups (already unique, but helps with queries)
CREATE INDEX profiles_username_idx ON public.profiles(username) WHERE username IS NOT NULL;

-- Created_at index for chronological queries
CREATE INDEX profiles_created_at_idx ON public.profiles(created_at);

-- Create trigger function for automatic updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = TIMEZONE('utc'::text, NOW());
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply the trigger to profiles table
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users can view all profiles (public data)
-- This allows for public profile discovery and social features
CREATE POLICY "Profiles are publicly readable"
    ON public.profiles
    FOR SELECT
    USING (true);

-- RLS Policy: Users can only insert their own profile
-- Uses auth.email() to match the profile email with the authenticated user's email
CREATE POLICY "Users can insert their own profile"
    ON public.profiles
    FOR INSERT
    WITH CHECK (email = auth.email());

-- RLS Policy: Users can only update their own profile
-- Uses auth.email() for authorization instead of user_id foreign key
CREATE POLICY "Users can update their own profile"
    ON public.profiles
    FOR UPDATE
    USING (email = auth.email())
    WITH CHECK (email = auth.email());

-- RLS Policy: Users can only delete their own profile
-- Uses auth.email() for authorization
CREATE POLICY "Users can delete their own profile"
    ON public.profiles
    FOR DELETE
    USING (email = auth.email());

-- Grant necessary permissions
GRANT ALL ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO anon;

COMMIT;

-- Migration Benefits:
-- 1. No foreign key constraints = no dependency issues
-- 2. Username-based identification = more flexible user system
-- 3. Email-based authorization = simpler RLS policies
-- 4. Optional username = users can remain anonymous
-- 5. Direct auth.uid()/auth.email() usage = more reliable authorization
-- 6. Proper indexing = better query performance
-- 7. Automatic timestamps = better data tracking
-- 8. Includes location field = complete user profiles