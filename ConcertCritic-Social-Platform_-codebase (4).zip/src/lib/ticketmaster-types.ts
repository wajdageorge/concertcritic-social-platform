// Ticketmaster API Response Interfaces
export interface TicketmasterApiResponse<T> {
  _embedded?: {
    events?: T[];
    venues?: TicketmasterVenue[];
    attractions?: TicketmasterAttraction[];
  };
  _links?: {
    self: TicketmasterLink;
    next?: TicketmasterLink;
    prev?: TicketmasterLink;
    first?: TicketmasterLink;
    last?: TicketmasterLink;
  };
  page?: {
    size: number;
    totalElements: number;
    totalPages: number;
    number: number;
  };
}

export interface TicketmasterLink {
  href: string;
  templated?: boolean;
}

/**
 * Raw Ticketmaster Event data structure
 * Represents the complete event object as returned by Ticketmaster Discovery API
 */
export interface TicketmasterEvent {
  /** Unique event identifier */
  id: string;
  /** Event name/title */
  name: string;
  /** Event type (e.g., 'event') */
  type: string;
  /** URL to the event page on Ticketmaster */
  url?: string;
  /** Event locale information */
  locale?: string;
  /** Array of event images in different sizes */
  images?: TicketmasterImage[];
  /** Event sales information */
  sales?: {
    public?: {
      startDateTime?: string;
      startTBD?: boolean;
      startTBA?: boolean;
      endDateTime?: string;
    };
    presales?: TicketmasterPresale[];
  };
  /** Event dates and times */
  dates: {
    start: {
      /** Local date in YYYY-MM-DD format */
      localDate?: string;
      /** Local time in HH:MM:SS format */
      localTime?: string;
      /** Date and time in ISO 8601 format */
      dateTime?: string;
      /** Whether date is to be determined */
      dateTBD?: boolean;
      /** Whether date is to be announced */
      dateTBA?: boolean;
      /** Whether time is to be determined */
      timeTBD?: boolean;
      /** Whether time is to be announced */
      timeTBA?: boolean;
      /** Whether date/time has no specific time */
      noSpecificTime?: boolean;
    };
    /** Timezone for the event */
    timezone?: string;
    /** Event status (onsale, offsale, soldout, cancelled, etc.) */
    status?: {
      code: string;
    };
    /** Indicates if this spans multiple days */
    spanMultipleDays?: boolean;
  };
  /** Event classifications (genre, segment, etc.) */
  classifications?: TicketmasterClassification[];
  /** Promoter information */
  promoter?: {
    id?: string;
    name?: string;
    description?: string;
  };
  /** Promoters array */
  promoters?: Array<{
    id: string;
    name: string;
    description?: string;
  }>;
  /** Price ranges for tickets */
  priceRanges?: TicketmasterPriceRange[];
  /** Additional event information */
  info?: string;
  /** Please note field for additional info */
  pleaseNote?: string;
  /** Accessibility information */
  accessibility?: {
    ticketLimit?: number;
    info?: string;
  };
  /** Age restrictions */
  ageRestrictions?: {
    legalAgeEnforced?: boolean;
  };
  /** Ticket limits */
  ticketLimit?: {
    info?: string;
  };
  /** Seat map information */
  seatmap?: {
    staticUrl?: string;
  };
  /** Event outlets */
  outlets?: Array<{
    url?: string;
    type?: string;
  }>;
  /** Related products */
  products?: Array<{
    id?: string;
    url?: string;
    type?: string;
    name?: string;
  }>;
  /** Embedded related data */
  _embedded?: {
    venues?: TicketmasterVenue[];
    attractions?: TicketmasterAttraction[];
  };
  /** Links to related resources */
  _links?: {
    self: TicketmasterLink;
    venues?: TicketmasterLink[];
    attractions?: TicketmasterLink[];
  };
}

/**
 * Ticketmaster venue information
 */
export interface TicketmasterVenue {
  /** Unique venue identifier */
  id: string;
  /** Venue name */
  name: string;
  /** Venue type */
  type: string;
  /** Venue URL */
  url?: string;
  /** Venue locale */
  locale?: string;
  /** Distance from search location (if applicable) */
  distance?: number;
  /** Distance units */
  units?: string;
  /** Postal code */
  postalCode?: string;
  /** Timezone */
  timezone?: string;
  /** Venue images */
  images?: TicketmasterImage[];
  /** Venue city */
  city?: {
    name: string;
  };
  /** Venue state */
  state?: {
    name: string;
    stateCode: string;
  };
  /** Venue country */
  country?: {
    name: string;
    countryCode: string;
  };
  /** Venue address */
  address?: {
    line1?: string;
    line2?: string;
    line3?: string;
  };
  /** Venue location coordinates */
  location?: {
    longitude: string;
    latitude: string;
  };
  /** Venue markets */
  markets?: Array<{
    id: string;
    name?: string;
  }>;
  /** Venue DMA (Designated Market Area) */
  dmas?: Array<{
    id: number;
  }>;
  /** Social media links */
  social?: {
    twitter?: {
      handle?: string;
    };
  };
  /** Box office information */
  boxOfficeInfo?: {
    phoneNumberDetail?: string;
    openHoursDetail?: string;
    acceptedPaymentDetail?: string;
    willCallDetail?: string;
  };
  /** Parking information */
  parkingDetail?: string;
  /** Accessibility information */
  accessibleSeatingDetail?: string;
  /** General venue information */
  generalInfo?: {
    generalRule?: string;
    childRule?: string;
  };
  /** Links to related resources */
  _links?: {
    self: TicketmasterLink;
  };
}

/**
 * Ticketmaster attraction (artist/performer) information
 */
export interface TicketmasterAttraction {
  /** Unique attraction identifier */
  id: string;
  /** Attraction name */
  name: string;
  /** Attraction type */
  type: string;
  /** URL to attraction page */
  url?: string;
  /** Attraction locale */
  locale?: string;
  /** Array of attraction images */
  images?: TicketmasterImage[];
  /** Attraction classifications */
  classifications?: TicketmasterClassification[];
  /** Additional information about the attraction */
  additionalInfo?: string;
  /** External links */
  externalLinks?: {
    youtube?: Array<{
      url: string;
    }>;
    twitter?: Array<{
      url: string;
    }>;
    itunes?: Array<{
      url: string;
    }>;
    lastfm?: Array<{
      url: string;
    }>;
    facebook?: Array<{
      url: string;
    }>;
    wiki?: Array<{
      url: string;
    }>;
    musicbrainz?: Array<{
      id: string;
    }>;
    homepage?: Array<{
      url: string;
    }>;
    spotify?: Array<{
      url: string;
    }>;
    instagram?: Array<{
      url: string;
    }>;
  };
  /** Attraction aliases */
  aliases?: string[];
  /** Test flag */
  test?: boolean;
  /** Links to related resources */
  _links?: {
    self: TicketmasterLink;
  };
}

/**
 * Image data structure used across Ticketmaster API
 */
export interface TicketmasterImage {
  /** Image URL */
  url: string;
  /** Image width in pixels */
  width: number;
  /** Image height in pixels */
  height: number;
  /** Aspect ratio classification (e.g., '16_9', '3_2', '4_3') */
  ratio?: string;
  /** Fallback flag */
  fallback?: boolean;
  /** Attribution information */
  attribution?: string;
}

/**
 * Price range information for tickets
 */
export interface TicketmasterPriceRange {
  /** Price type (e.g., 'standard', 'including fees') */
  type: string;
  /** Currency code (e.g., 'USD') */
  currency: string;
  /** Minimum price */
  min?: number;
  /** Maximum price */
  max?: number;
}

/**
 * Event classification (genre, segment, type)
 */
export interface TicketmasterClassification {
  /** Whether this is the primary classification */
  primary?: boolean;
  /** Segment information (e.g., Music, Sports) */
  segment?: {
    id: string;
    name: string;
  };
  /** Genre information (e.g., Rock, Pop, Classical) */
  genre?: {
    id: string;
    name: string;
  };
  /** Sub-genre information */
  subGenre?: {
    id: string;
    name: string;
  };
  /** Type information (e.g., Individual, Group) */
  type?: {
    id: string;
    name: string;
  };
  /** Sub-type information */
  subType?: {
    id: string;
    name: string;
  };
  /** Family flag */
  family?: boolean;
}

/**
 * Presale information
 */
export interface TicketmasterPresale {
  /** Presale start date/time */
  startDateTime?: string;
  /** Presale end date/time */
  endDateTime?: string;
  /** Presale name */
  name?: string;
  /** Presale description */
  description?: string;
  /** Presale URL */
  url?: string;
}

// Normalized Internal Data Structures

/**
 * Normalized concert data used throughout the application
 */
export interface Concert {
  /** Unique concert identifier */
  id: string;
  /** Concert title/name */
  title: string;
  /** Main artist/performer */
  artist: Artist;
  /** Supporting artists */
  supportingArtists?: Artist[];
  /** Concert venue */
  venue: Venue;
  /** Concert date and time */
  date: Date;
  /** Local date string (YYYY-MM-DD) */
  localDate: string;
  /** Local time string (HH:MM) */
  localTime?: string;
  /** Concert status */
  status: EventStatus;
  /** Concert genre */
  genre: string;
  /** Sub-genre */
  subGenre?: string;
  /** Ticket pricing information */
  pricing: PriceInfo;
  /** Concert images */
  images: ImageInfo[];
  /** Main promotional image */
  primaryImage?: string;
  /** Concert description */
  description?: string;
  /** Additional notes */
  notes?: string;
  /** Age restrictions */
  ageRestriction?: string;
  /** Ticketmaster URL */
  ticketmasterUrl?: string;
  /** Distance from user (if location-based search) */
  distance?: number;
  /** Distance units */
  distanceUnits?: string;
  /** Whether tickets are currently on sale */
  onSale: boolean;
  /** Sale start date/time */
  saleStartDate?: Date;
  /** Sale end date/time */
  saleEndDate?: Date;
  /** Presale information */
  presales?: PresaleInfo[];
  /** Timezone for the event */
  timezone?: string;
  /** Popularity score (0-100) */
  popularity?: number;
}

/**
 * Normalized venue information
 */
export interface Venue {
  /** Unique venue identifier */
  id: string;
  /** Venue name */
  name: string;
  /** Full address */
  address: Address;
  /** Venue capacity */
  capacity?: number;
  /** Venue images */
  images?: ImageInfo[];
  /** Distance from search location */
  distance?: number;
  /** Geographic coordinates */
  coordinates?: Coordinates;
  /** Venue website URL */
  website?: string;
  /** Phone number */
  phone?: string;
  /** Parking information */
  parking?: string;
  /** Accessibility information */
  accessibility?: string;
  /** Box office hours */
  boxOfficeHours?: string;
  /** Social media links */
  socialMedia?: SocialMediaLinks;
}

/**
 * Normalized artist information
 */
export interface Artist {
  /** Unique artist identifier */
  id: string;
  /** Artist name */
  name: string;
  /** Artist genre */
  genre?: string;
  /** Artist images */
  images?: ImageInfo[];
  /** Artist description */
  description?: string;
  /** External links (Spotify, social media, etc.) */
  externalLinks?: ExternalLinks;
  /** Artist aliases/alternative names */
  aliases?: string[];
}

/**
 * Price information for concerts
 */
export interface PriceInfo {
  /** Currency code */
  currency: string;
  /** Minimum ticket price */
  min?: number;
  /** Maximum ticket price */
  max?: number;
  /** Whether prices include fees */
  includesFees?: boolean;
  /** Price ranges by category */
  ranges?: Array<{
    category: string;
    min: number;
    max: number;
  }>;
}

/**
 * Image information
 */
export interface ImageInfo {
  /** Image URL */
  url: string;
  /** Image width */
  width: number;
  /** Image height */
  height: number;
  /** Aspect ratio */
  aspectRatio?: string;
  /** Image type/category */
  type?: 'primary' | 'thumbnail' | 'background' | 'artist';
}

/**
 * Address information
 */
export interface Address {
  /** Street address line 1 */
  street?: string;
  /** Street address line 2 */
  street2?: string;
  /** City */
  city: string;
  /** State/province */
  state: string;
  /** State/province code */
  stateCode?: string;
  /** Country */
  country: string;
  /** Country code */
  countryCode: string;
  /** Postal/ZIP code */
  postalCode?: string;
  /** Formatted address string */
  formatted?: string;
}

/**
 * Geographic coordinates
 */
export interface Coordinates {
  /** Latitude */
  latitude: number;
  /** Longitude */
  longitude: number;
}

/**
 * Presale information
 */
export interface PresaleInfo {
  /** Presale name */
  name: string;
  /** Presale description */
  description?: string;
  /** Presale start date/time */
  startDate: Date;
  /** Presale end date/time */
  endDate: Date;
  /** Presale access URL */
  url?: string;
}

/**
 * Social media links
 */
export interface SocialMediaLinks {
  facebook?: string;
  twitter?: string;
  instagram?: string;
  website?: string;
}

/**
 * External links for artists
 */
export interface ExternalLinks {
  spotify?: string;
  youtube?: string;
  facebook?: string;
  twitter?: string;
  instagram?: string;
  website?: string;
  lastfm?: string;
  musicbrainz?: string;
}

// Search and Filter Types

/**
 * Search parameters for concert discovery
 */
export interface SearchParams {
  /** Search query (artist, venue, event name) */
  keyword?: string;
  /** Location-based search */
  location?: LocationFilter;
  /** Date range filter */
  dateRange?: DateRangeFilter;
  /** Genre filter */
  genre?: string[];
  /** Price range filter */
  priceRange?: PriceRangeFilter;
  /** Venue capacity filter */
  venueSize?: VenueSizeFilter;
  /** Sort options */
  sort?: SortOption;
  /** Number of results per page */
  limit?: number;
  /** Page offset */
  offset?: number;
  /** Search radius for location-based searches */
  radius?: number;
  /** Distance units for radius */
  radiusUnits?: 'miles' | 'km';
}

/**
 * Location-based search filter
 */
export interface LocationFilter {
  /** City name */
  city?: string;
  /** State/province */
  state?: string;
  /** Country */
  country?: string;
  /** Postal code */
  postalCode?: string;
  /** Geographic coordinates */
  coordinates?: Coordinates;
  /** Search radius */
  radius?: number;
  /** Radius units */
  units?: 'miles' | 'km';
}

/**
 * Date range filter for events
 */
export interface DateRangeFilter {
  /** Start date */
  startDate?: Date;
  /** End date */
  endDate?: Date;
  /** Specific date */
  date?: Date;
  /** Include events with TBD/TBA dates */
  includeTBD?: boolean;
}

/**
 * Price range filter
 */
export interface PriceRangeFilter {
  /** Minimum price */
  min?: number;
  /** Maximum price */
  max?: number;
  /** Currency */
  currency?: string;
}

/**
 * Venue size filter
 */
export interface VenueSizeFilter {
  /** Small venues (< 1000 capacity) */
  small?: boolean;
  /** Medium venues (1000-5000 capacity) */
  medium?: boolean;
  /** Large venues (5000-20000 capacity) */
  large?: boolean;
  /** Arena/stadium venues (> 20000 capacity) */
  arena?: boolean;
}

// Utility Types

/**
 * Available sort options for search results
 */
export type SortOption = 
  | 'date_asc'           // Date ascending (earliest first)
  | 'date_desc'          // Date descending (latest first)
  | 'popularity_desc'    // Popularity descending
  | 'name_asc'          // Alphabetical by name
  | 'distance_asc'      // Distance ascending (closest first)
  | 'price_asc'         // Price ascending (cheapest first)
  | 'price_desc'        // Price descending (most expensive first)
  | 'relevance';        // Relevance to search query

/**
 * Event status enumeration
 */
export type EventStatus =
  | 'onsale'      // Tickets on sale
  | 'presale'     // In presale period
  | 'soldout'     // Sold out
  | 'cancelled'   // Event cancelled
  | 'postponed'   // Event postponed
  | 'rescheduled' // Event rescheduled
  | 'offsale'     // Not currently on sale
  | 'expired';    // Event has passed

/**
 * Genre categories
 */
export type GenreCategory =
  | 'Rock'
  | 'Pop'
  | 'Hip-Hop/Rap'
  | 'Electronic'
  | 'Country'
  | 'Jazz'
  | 'Classical'
  | 'R&B'
  | 'Alternative'
  | 'Metal'
  | 'Indie'
  | 'Folk'
  | 'Blues'
  | 'Reggae'
  | 'World'
  | 'Comedy'
  | 'Theater'
  | 'Family'
  | 'Other';

// API Response Wrappers

/**
 * Standardized API response wrapper
 */
export interface ApiResponse<T> {
  /** Response data */
  data?: T;
  /** Success flag */
  success: boolean;
  /** Error information if request failed */
  error?: ApiError;
  /** Response metadata */
  meta?: ResponseMetadata;
}

/**
 * Paginated API response wrapper
 */
export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  /** Pagination information */
  pagination?: PaginationInfo;
}

/**
 * Pagination metadata
 */
export interface PaginationInfo {
  /** Current page number */
  page: number;
  /** Number of items per page */
  limit: number;
  /** Total number of items */
  total: number;
  /** Total number of pages */
  totalPages: number;
  /** Whether there are more pages */
  hasNext: boolean;
  /** Whether there are previous pages */
  hasPrev: boolean;
}

/**
 * Response metadata
 */
export interface ResponseMetadata {
  /** Request timestamp */
  timestamp: string;
  /** Request ID for tracking */
  requestId?: string;
  /** Response time in milliseconds */
  responseTime?: number;
  /** API version */
  version?: string;
}

// Error Handling Types

/**
 * Standardized API error structure
 */
export interface ApiError {
  /** Error code */
  code: string;
  /** Human-readable error message */
  message: string;
  /** Detailed error description */
  details?: string;
  /** Field-specific errors */
  fieldErrors?: Record<string, string[]>;
  /** HTTP status code */
  status?: number;
  /** Timestamp when error occurred */
  timestamp?: string;
  /** Error trace ID for debugging */
  traceId?: string;
}

/**
 * Specific error types for different scenarios
 */
export type ApiErrorType =
  | 'NETWORK_ERROR'         // Network connectivity issues
  | 'TIMEOUT_ERROR'         // Request timeout
  | 'AUTHENTICATION_ERROR'  // API key issues
  | 'AUTHORIZATION_ERROR'   // Insufficient permissions
  | 'VALIDATION_ERROR'      // Invalid request parameters
  | 'NOT_FOUND_ERROR'      // Resource not found
  | 'RATE_LIMIT_ERROR'     // API rate limit exceeded
  | 'SERVER_ERROR'         // Internal server error
  | 'SERVICE_UNAVAILABLE'  // Service temporarily unavailable
  | 'UNKNOWN_ERROR';       // Unexpected error

/**
 * Error context for better error handling
 */
export interface ErrorContext {
  /** The action being performed when error occurred */
  action: string;
  /** Additional context data */
  context?: Record<string, any>;
  /** Whether the operation can be retried */
  retryable?: boolean;
  /** Suggested retry delay in milliseconds */
  retryAfter?: number;
}

/**
 * Search result statistics
 */
export interface SearchStats {
  /** Total number of events found */
  totalEvents: number;
  /** Number of unique venues */
  uniqueVenues: number;
  /** Number of unique artists */
  uniqueArtists: number;
  /** Date range of results */
  dateRange?: {
    earliest: Date;
    latest: Date;
  };
  /** Price range of results */
  priceRange?: {
    min: number;
    max: number;
    currency: string;
  };
  /** Search execution time */
  searchTime?: number;
}