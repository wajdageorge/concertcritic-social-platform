import supabase from '@/lib/supabase';
import type { User } from '@supabase/supabase-js';

// Custom Error Types
export class FollowSystemError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number = 500
  ) {
    super(message);
    this.name = 'FollowSystemError';
  }
}

export class AuthenticationError extends FollowSystemError {
  constructor(message: string = 'User not authenticated') {
    super(message, 'AUTH_ERROR', 401);
  }
}

export class NotFoundError extends FollowSystemError {
  constructor(message: string = 'Resource not found') {
    super(message, 'NOT_FOUND', 404);
  }
}

export class ValidationError extends FollowSystemError {
  constructor(message: string = 'Invalid input') {
    super(message, 'VALIDATION_ERROR', 400);
  }
}

// TypeScript Interfaces
export interface UserProfile {
  id: string;
  username: string;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  email: string;
  created_at: string;
  updated_at: string;
  follower_count: number;
  following_count: number;
  review_count: number;
  is_verified: boolean;
}

export interface SearchResult {
  users: UserProfile[];
  total_count: number;
  has_more: boolean;
  next_offset?: number;
}

export interface FollowRelationship {
  id: string;
  follower_id: string;
  following_id: string;
  created_at: string;
  follower?: UserProfile;
  following?: UserProfile;
}

export interface FollowStats {
  followers: number;
  following: number;
  mutual_follows: number;
}

export interface ApiResponse<T> {
  data: T | null;
  error: FollowSystemError | null;
}

// Debounce helper
function debounce<T extends (...args: any[]) => any>(
  func: T,
  delay: number
): (...args: Parameters<T>) => Promise<ReturnType<T>> {
  let timeoutId: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    return new Promise((resolve) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        resolve(func(...args));
      }, delay);
    });
  };
}

// Get current user helper
async function getCurrentUser(): Promise<User> {
  const { data: { user }, error } = await supabase.auth.getUser();
  
  if (error || !user) {
    throw new AuthenticationError();
  }
  
  return user;
}

// Search users by username or display name
export async function searchUsers(
  query: string,
  limit: number = 20,
  offset: number = 0
): Promise<ApiResponse<SearchResult>> {
  try {
    if (!query.trim()) {
      throw new ValidationError('Search query cannot be empty');
    }

    const searchTerm = `%${query.trim()}%`;
    
    // Get total count
    const { count, error: countError } = await supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true })
      .or(`username.ilike.${searchTerm},display_name.ilike.${searchTerm}`);

    if (countError) {
      throw new FollowSystemError('Failed to get search count', 'SEARCH_COUNT_ERROR');
    }

    // Get paginated results
    const { data, error } = await supabase
      .from('profiles')
      .select(`
        id,
        username,
        display_name,
        avatar_url,
        bio,
        email,
        created_at,
        updated_at,
        follower_count,
        following_count,
        review_count,
        is_verified
      `)
      .or(`username.ilike.${searchTerm},display_name.ilike.${searchTerm}`)
      .order('follower_count', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      throw new FollowSystemError('Failed to search users', 'SEARCH_ERROR');
    }

    return {
      data: {
        users: data || [],
        total_count: count || 0,
        has_more: (offset + limit) < (count || 0),
        next_offset: (offset + limit) < (count || 0) ? offset + limit : undefined
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Search failed', 'UNKNOWN_ERROR')
    };
  }
}

// Debounced version of searchUsers
export const debouncedSearchUsers = debounce(searchUsers, 300);

// Follow a user
export async function followUser(userId: string): Promise<ApiResponse<FollowRelationship>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const currentUser = await getCurrentUser();
    
    if (currentUser.id === userId) {
      throw new ValidationError('Cannot follow yourself');
    }

    // Check if already following
    const { data: existing } = await supabase
      .from('follows')
      .select('id')
      .eq('follower_id', currentUser.id)
      .eq('following_id', userId)
      .single();

    if (existing) {
      throw new ValidationError('Already following this user');
    }

    // Create follow relationship
    const { data, error } = await supabase
      .from('follows')
      .insert({
        follower_id: currentUser.id,
        following_id: userId
      })
      .select(`
        id,
        follower_id,
        following_id,
        created_at,
        following:profiles!follows_following_id_fkey(
          id,
          username,
          display_name,
          avatar_url,
          bio,
          email,
          created_at,
          updated_at,
          follower_count,
          following_count,
          review_count,
          is_verified
        )
      `)
      .single();

    if (error) {
      if (error.code === '23503') {
        throw new NotFoundError('User not found');
      }
      throw new FollowSystemError('Failed to follow user', 'FOLLOW_ERROR');
    }

    return { data, error: null };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Follow failed', 'UNKNOWN_ERROR')
    };
  }
}

// Unfollow a user
export async function unfollowUser(userId: string): Promise<ApiResponse<boolean>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const currentUser = await getCurrentUser();

    const { error } = await supabase
      .from('follows')
      .delete()
      .eq('follower_id', currentUser.id)
      .eq('following_id', userId);

    if (error) {
      throw new FollowSystemError('Failed to unfollow user', 'UNFOLLOW_ERROR');
    }

    return { data: true, error: null };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Unfollow failed', 'UNKNOWN_ERROR')
    };
  }
}

// Check if current user is following a specific user
export async function isFollowing(userId: string): Promise<ApiResponse<boolean>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const currentUser = await getCurrentUser();
    const supabase = createClient();

    const { data, error } = await supabase
      .from('follows')
      .select('id')
      .eq('follower_id', currentUser.id)
      .eq('following_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned"
      throw new FollowSystemError('Failed to check follow status', 'IS_FOLLOWING_ERROR');
    }

    return { data: !!data, error: null };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Check follow status failed', 'UNKNOWN_ERROR')
    };
  }
}

// Get followers of a user
export async function getFollowers(
  userId: string,
  limit: number = 20,
  offset: number = 0
): Promise<ApiResponse<{ followers: UserProfile[], total_count: number, has_more: boolean }>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const supabase = createClient();

    // Get total count
    const { count, error: countError } = await supabase
      .from('follows')
      .select('*', { count: 'exact', head: true })
      .eq('following_id', userId);

    if (countError) {
      throw new FollowSystemError('Failed to get followers count', 'FOLLOWERS_COUNT_ERROR');
    }

    // Get paginated followers
    const { data, error } = await supabase
      .from('follows')
      .select(`
        follower:profiles!follows_follower_id_fkey(
          id,
          username,
          display_name,
          avatar_url,
          bio,
          email,
          created_at,
          updated_at,
          follower_count,
          following_count,
          review_count,
          is_verified
        )
      `)
      .eq('following_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      throw new FollowSystemError('Failed to get followers', 'FOLLOWERS_ERROR');
    }

    const followers = data?.map(item => item.follower).filter(Boolean) || [];

    return {
      data: {
        followers,
        total_count: count || 0,
        has_more: (offset + limit) < (count || 0)
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Get followers failed', 'UNKNOWN_ERROR')
    };
  }
}

// Get users that a specific user is following
export async function getFollowing(
  userId: string,
  limit: number = 20,
  offset: number = 0
): Promise<ApiResponse<{ following: UserProfile[], total_count: number, has_more: boolean }>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const supabase = createClient();

    // Get total count
    const { count, error: countError } = await supabase
      .from('follows')
      .select('*', { count: 'exact', head: true })
      .eq('follower_id', userId);

    if (countError) {
      throw new FollowSystemError('Failed to get following count', 'FOLLOWING_COUNT_ERROR');
    }

    // Get paginated following
    const { data, error } = await supabase
      .from('follows')
      .select(`
        following:profiles!follows_following_id_fkey(
          id,
          username,
          display_name,
          avatar_url,
          bio,
          email,
          created_at,
          updated_at,
          follower_count,
          following_count,
          review_count,
          is_verified
        )
      `)
      .eq('follower_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      throw new FollowSystemError('Failed to get following', 'FOLLOWING_ERROR');
    }

    const following = data?.map(item => item.following).filter(Boolean) || [];

    return {
      data: {
        following,
        total_count: count || 0,
        has_more: (offset + limit) < (count || 0)
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Get following failed', 'UNKNOWN_ERROR')
    };
  }
}

// Get detailed user profile
export async function getUserProfile(userId: string): Promise<ApiResponse<UserProfile>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const supabase = createClient();

    const { data, error } = await supabase
      .from('profiles')
      .select(`
        id,
        username,
        display_name,
        avatar_url,
        bio,
        email,
        created_at,
        updated_at,
        follower_count,
        following_count,
        review_count,
        is_verified
      `)
      .eq('id', userId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        throw new NotFoundError('User not found');
      }
      throw new FollowSystemError('Failed to get user profile', 'PROFILE_ERROR');
    }

    return { data, error: null };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Get profile failed', 'UNKNOWN_ERROR')
    };
  }
}

// Get mutual follows (users who follow each other)
export async function getMutualFollows(
  userId: string,
  limit: number = 20,
  offset: number = 0
): Promise<ApiResponse<{ mutuals: UserProfile[], total_count: number, has_more: boolean }>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const currentUser = await getCurrentUser();
    const supabase = createClient();

    // Get users that both current user and target user follow
    const { data, error, count } = await supabase
      .from('follows')
      .select(`
        following:profiles!follows_following_id_fkey(
          id,
          username,
          display_name,
          avatar_url,
          bio,
          email,
          created_at,
          updated_at,
          follower_count,
          following_count,
          review_count,
          is_verified
        )
      `, { count: 'exact' })
      .eq('follower_id', currentUser.id)
      .in('following_id', 
        supabase
          .from('follows')
          .select('following_id')
          .eq('follower_id', userId)
      )
      .range(offset, offset + limit - 1);

    if (error) {
      throw new FollowSystemError('Failed to get mutual follows', 'MUTUAL_FOLLOWS_ERROR');
    }

    const mutuals = data?.map(item => item.following).filter(Boolean) || [];

    return {
      data: {
        mutuals,
        total_count: count || 0,
        has_more: (offset + limit) < (count || 0)
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Get mutual follows failed', 'UNKNOWN_ERROR')
    };
  }
}

// Real-time subscription helpers
export function subscribeToFollowUpdates(
  userId: string,
  onUpdate: (payload: any) => void
) {
  const supabase = createClient();
  
  const subscription = supabase
    .channel(`follow-updates-${userId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'follows',
        filter: `or(follower_id.eq.${userId},following_id.eq.${userId})`
      },
      onUpdate
    )
    .subscribe();

  return subscription;
}

export function subscribeToUserProfileUpdates(
  userId: string,
  onUpdate: (payload: any) => void
) {
  const supabase = createClient();
  
  const subscription = supabase
    .channel(`profile-updates-${userId}`)
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'profiles',
        filter: `id=eq.${userId}`
      },
      onUpdate
    )
    .subscribe();

  return subscription;
}

// Get follow stats for a user
export async function getFollowStats(userId: string): Promise<ApiResponse<FollowStats>> {
  try {
    if (!userId) {
      throw new ValidationError('User ID is required');
    }

    const supabase = createClient();

    // Get follower count
    const { count: followers, error: followersError } = await supabase
      .from('follows')
      .select('*', { count: 'exact', head: true })
      .eq('following_id', userId);

    if (followersError) {
      throw new FollowSystemError('Failed to get followers count', 'STATS_ERROR');
    }

    // Get following count
    const { count: following, error: followingError } = await supabase
      .from('follows')
      .select('*', { count: 'exact', head: true })
      .eq('follower_id', userId);

    if (followingError) {
      throw new FollowSystemError('Failed to get following count', 'STATS_ERROR');
    }

    // Get mutual follows count (users who follow this user and this user follows back)
    const { count: mutual_follows, error: mutualError } = await supabase
      .from('follows')
      .select('*', { count: 'exact', head: true })
      .eq('follower_id', userId)
      .in('following_id', 
        supabase
          .from('follows')
          .select('follower_id')
          .eq('following_id', userId)
      );

    if (mutualError) {
      throw new FollowSystemError('Failed to get mutual follows count', 'STATS_ERROR');
    }

    return {
      data: {
        followers: followers || 0,
        following: following || 0,
        mutual_follows: mutual_follows || 0
      },
      error: null
    };
  } catch (error) {
    return {
      data: null,
      error: error instanceof FollowSystemError ? error : new FollowSystemError('Get stats failed', 'UNKNOWN_ERROR')
    };
  }
}