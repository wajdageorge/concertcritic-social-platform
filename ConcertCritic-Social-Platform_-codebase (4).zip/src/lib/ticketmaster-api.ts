import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

/**
 * Ticketmaster API Configuration
 */
interface TicketmasterConfig {
  apiKey: string;
  baseURL?: string;
  timeout?: number;
  rateLimitDelay?: number;
  maxRetries?: number;
}

/**
 * Search parameters for events
 */
interface EventSearchParams {
  keyword?: string;
  attractionId?: string;
  venueId?: string;
  city?: string;
  stateCode?: string;
  countryCode?: string;
  postalCode?: string;
  latlong?: string;
  radius?: string;
  unit?: 'miles' | 'km';
  startDateTime?: string;
  endDateTime?: string;
  classificationName?: string;
  classificationId?: string;
  size?: number;
  page?: number;
  sort?: 'name,asc' | 'name,desc' | 'date,asc' | 'date,desc' | 'relevance,asc' | 'relevance,desc' | 'distance,asc' | 'name,desc' | 'venueName,asc' | 'venueName,desc' | 'random';
  includeTBA?: 'yes' | 'no' | 'only';
  includeTBD?: 'yes' | 'no' | 'only';
  includeTest?: 'yes' | 'no' | 'only';
  source?: string;
  locale?: string;
  marketId?: string;
  onsaleStartDateTime?: string;
  onsaleEndDateTime?: string;
  segmentId?: string;
  segmentName?: string;
  genreId?: string;
  genreName?: string;
  subGenreId?: string;
  subGenreName?: string;
  typeId?: string;
  typeName?: string;
  subTypeId?: string;
  subTypeName?: string;
  geoPoint?: string;
  preferredCountry?: string;
  includeSpellcheck?: 'yes' | 'no';
}

/**
 * Venue search parameters
 */
interface VenueSearchParams {
  keyword?: string;
  city?: string;
  stateCode?: string;
  countryCode?: string;
  postalCode?: string;
  latlong?: string;
  radius?: string;
  unit?: 'miles' | 'km';
  size?: number;
  page?: number;
  sort?: 'name,asc' | 'name,desc' | 'relevance,asc' | 'relevance,desc' | 'distance,asc';
  locale?: string;
  includeTest?: 'yes' | 'no' | 'only';
  source?: string;
}

/**
 * Artist/Attraction search parameters
 */
interface AttractionSearchParams {
  keyword?: string;
  size?: number;
  page?: number;
  sort?: 'name,asc' | 'name,desc' | 'relevance,asc' | 'relevance,desc';
  classificationName?: string;
  classificationId?: string;
  locale?: string;
  includeTest?: 'yes' | 'no' | 'only';
  source?: string;
}

/**
 * Geocoding parameters
 */
interface GeocodingParams {
  address: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
}

/**
 * Coordinates interface
 */
interface Coordinates {
  latitude: number;
  longitude: number;
}

/**
 * Internal Concert format
 */
interface Concert {
  id: string;
  name: string;
  description?: string;
  date: string;
  time?: string;
  venue: Venue;
  artists: Artist[];
  genres: string[];
  images: Image[];
  ticketInfo: TicketInfo;
  priceRange?: PriceRange;
  status: string;
  url: string;
  seatmap?: string;
  accessibility?: string[];
  ageRestrictions?: string;
  classification: Classification;
  promoter?: Promoter;
  pleaseNote?: string;
  distance?: number;
}

/**
 * Internal Venue format
 */
interface Venue {
  id: string;
  name: string;
  address: Address;
  city: string;
  state?: string;
  country: string;
  postalCode?: string;
  timezone?: string;
  coordinates?: Coordinates;
  capacity?: number;
  images: Image[];
  boxOfficeInfo?: BoxOfficeInfo;
  parkingInfo?: string;
  accessibleSeatingDetail?: string;
  generalInfo?: GeneralInfo;
  url?: string;
  upcomingEvents?: number;
  distance?: number;
}

/**
 * Internal Artist format
 */
interface Artist {
  id: string;
  name: string;
  url?: string;
  images: Image[];
  classification: Classification;
  upcomingEvents?: number;
  externalLinks?: ExternalLinks;
}

/**
 * Supporting interfaces
 */
interface Image {
  url: string;
  width?: number;
  height?: number;
  ratio?: string;
  fallback?: boolean;
}

interface Address {
  line1?: string;
  line2?: string;
  line3?: string;
}

interface TicketInfo {
  ticketLimit?: number;
  status: string;
  url?: string;
}

interface PriceRange {
  type: string;
  currency: string;
  min: number;
  max: number;
}

interface Classification {
  primary: boolean;
  segment?: ClassificationItem;
  genre?: ClassificationItem;
  subGenre?: ClassificationItem;
  type?: ClassificationItem;
  subType?: ClassificationItem;
  family?: boolean;
}

interface ClassificationItem {
  id: string;
  name: string;
}

interface Promoter {
  id: string;
  name: string;
  description?: string;
}

interface BoxOfficeInfo {
  phoneNumberDetail?: string;
  openHoursDetail?: string;
  acceptedPaymentDetail?: string;
  willCallDetail?: string;
}

interface GeneralInfo {
  generalRule?: string;
  childRule?: string;
}

interface ExternalLinks {
  twitter?: ExternalLink[];
  itunes?: ExternalLink[];
  lastfm?: ExternalLink[];
  facebook?: ExternalLink[];
  spotify?: ExternalLink[];
  musicbrainz?: ExternalLink[];
  youtube?: ExternalLink[];
  instagram?: ExternalLink[];
  homepage?: ExternalLink[];
}

interface ExternalLink {
  url: string;
}

/**
 * Ticketmaster API response interfaces
 */
interface TicketmasterEvent {
  id: string;
  name: string;
  type: string;
  url: string;
  locale: string;
  images: any[];
  sales: any;
  dates: any;
  classifications: any[];
  promoter?: any;
  promoters?: any[];
  priceRanges?: any[];
  seatmap?: any;
  accessibility?: any;
  ticketLimit?: any;
  ageRestrictions?: any;
  ticketing?: any;
  _links: any;
  _embedded?: {
    venues?: any[];
    attractions?: any[];
  };
  pleaseNote?: string;
  info?: string;
  distance?: number;
}

interface TicketmasterVenue {
  id: string;
  name: string;
  type: string;
  url?: string;
  locale: string;
  images: any[];
  postalCode?: string;
  timezone?: string;
  city: any;
  state?: any;
  country: any;
  address?: any;
  location?: any;
  markets?: any[];
  dmas?: any[];
  boxOfficeInfo?: any;
  parkingInfo?: any;
  accessibleSeatingDetail?: any;
  generalInfo?: any;
  upcomingEvents?: any;
  _links: any;
  distance?: number;
}

interface TicketmasterAttraction {
  id: string;
  name: string;
  type: string;
  url?: string;
  locale: string;
  images: any[];
  classifications: any[];
  upcomingEvents?: any;
  _links: any;
  externalLinks?: any;
}

/**
 * Error types
 */
class TicketmasterError extends Error {
  constructor(
    message: string,
    public statusCode?: number,
    public code?: string,
    public details?: any
  ) {
    super(message);
    this.name = 'TicketmasterError';
  }
}

class RateLimitError extends TicketmasterError {
  constructor(retryAfter?: number) {
    super('Rate limit exceeded', 429, 'RATE_LIMIT_EXCEEDED', { retryAfter });
    this.name = 'RateLimitError';
  }
}

class APIQuotaError extends TicketmasterError {
  constructor() {
    super('API quota exceeded', 429, 'API_QUOTA_EXCEEDED');
    this.name = 'APIQuotaError';
  }
}

/**
 * Cache implementation
 */
class APICache {
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  private defaultTTL = 5 * 60 * 1000; // 5 minutes

  set(key: string, data: any, ttl: number = this.defaultTTL): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  clear(): void {
    this.cache.clear();
  }

  delete(key: string): boolean {
    return this.cache.delete(key);
  }

  size(): number {
    return this.cache.size;
  }
}

/**
 * Request deduplication
 */
class RequestDeduplicator {
  private pendingRequests = new Map<string, Promise<any>>();

  async deduplicate<T>(key: string, requestFn: () => Promise<T>): Promise<T> {
    if (this.pendingRequests.has(key)) {
      return this.pendingRequests.get(key) as Promise<T>;
    }

    const promise = requestFn().finally(() => {
      this.pendingRequests.delete(key);
    });

    this.pendingRequests.set(key, promise);
    return promise;
  }
}

/**
 * Main Ticketmaster API utility class
 */
export class TicketmasterAPI {
  private client: AxiosInstance;
  private config: TicketmasterConfig;
  private cache = new APICache();
  private deduplicator = new RequestDeduplicator();
  private rateLimitDelay = 100; // ms between requests
  private lastRequestTime = 0;

  constructor(config: TicketmasterConfig) {
    this.config = {
      baseURL: 'https://app.ticketmaster.com/discovery/v2',
      timeout: 10000,
      rateLimitDelay: 100,
      maxRetries: 3,
      ...config
    };

    this.client = axios.create({
      baseURL: this.config.baseURL,
      timeout: this.config.timeout,
      params: {
        apikey: this.config.apiKey
      }
    });

    this.setupInterceptors();
  }

  /**
   * Setup request/response interceptors
   */
  private setupInterceptors(): void {
    // Request interceptor for rate limiting
    this.client.interceptors.request.use(async (config) => {
      const now = Date.now();
      const timeSinceLastRequest = now - this.lastRequestTime;
      
      if (timeSinceLastRequest < this.rateLimitDelay) {
        await new Promise(resolve => 
          setTimeout(resolve, this.rateLimitDelay - timeSinceLastRequest)
        );
      }
      
      this.lastRequestTime = Date.now();
      return config;
    });

    // Response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        if (error.response?.status === 429) {
          const retryAfter = error.response.headers['retry-after'];
          const delay = retryAfter ? parseInt(retryAfter) * 1000 : 5000;
          
          if (!originalRequest._retry && originalRequest._retryCount < this.config.maxRetries!) {
            originalRequest._retry = true;
            originalRequest._retryCount = (originalRequest._retryCount || 0) + 1;
            
            await new Promise(resolve => setTimeout(resolve, delay));
            return this.client(originalRequest);
          }
          
          throw new RateLimitError(retryAfter);
        }

        if (error.response?.status === 403 && error.response.data?.fault?.faultstring?.includes('quota')) {
          throw new APIQuotaError();
        }

        throw new TicketmasterError(
          error.message || 'API request failed',
          error.response?.status,
          error.code,
          error.response?.data
        );
      }
    );
  }

  /**
   * Make API request with caching and deduplication
   */
  private async makeRequest<T>(
    endpoint: string,
    params: any = {},
    cacheKey?: string,
    cacheTTL?: number
  ): Promise<T> {
    const key = cacheKey || `${endpoint}:${JSON.stringify(params)}`;
    
    // Check cache first
    const cachedData = this.cache.get(key);
    if (cachedData) {
      return cachedData;
    }

    // Deduplicate concurrent requests
    return this.deduplicator.deduplicate(key, async () => {
      const response = await this.client.get<T>(endpoint, { params });
      
      // Cache successful responses
      if (response.data) {
        this.cache.set(key, response.data, cacheTTL);
      }
      
      return response.data;
    });
  }

  /**
   * Search for events with comprehensive filtering
   */
  async searchEvents(params: EventSearchParams = {}): Promise<{
    events: Concert[];
    page: {
      size: number;
      totalElements: number;
      totalPages: number;
      number: number;
    };
  }> {
    const response: any = await this.makeRequest('/events.json', params, undefined, 2 * 60 * 1000);
    
    const events = response._embedded?.events?.map((event: TicketmasterEvent) =>
      this.transformTicketmasterEvent(event)
    ) || [];

    return {
      events,
      page: response.page || {
        size: events.length,
        totalElements: events.length,
        totalPages: 1,
        number: 0
      }
    };
  }

  /**
   * Get event by ID
   */
  async getEventById(eventId: string, locale?: string): Promise<Concert | null> {
    try {
      const params = locale ? { locale } : {};
      const response: any = await this.makeRequest(`/events/${eventId}.json`, params, undefined, 10 * 60 * 1000);
      return this.transformTicketmasterEvent(response);
    } catch (error) {
      if (error instanceof TicketmasterError && error.statusCode === 404) {
        return null;
      }
      throw error;
    }
  }

  /**
   * Get events at a specific venue
   */
  async getVenueEvents(venueId: string, params: Partial<EventSearchParams> = {}): Promise<{
    events: Concert[];
    page: any;
  }> {
    const searchParams = { ...params, venueId };
    return this.searchEvents(searchParams);
  }

  /**
   * Get events for a specific artist/attraction
   */
  async getArtistEvents(attractionId: string, params: Partial<EventSearchParams> = {}): Promise<{
    events: Concert[];
    page: any;
  }> {
    const searchParams = { ...params, attractionId };
    return this.searchEvents(searchParams);
  }

  /**
   * Search events by location (city, state, postal code)
   */
  async searchEventsByLocation(
    location: {
      city?: string;
      stateCode?: string;
      countryCode?: string;
      postalCode?: string;
    },
    params: Partial<EventSearchParams> = {}
  ): Promise<{
    events: Concert[];
    page: any;
  }> {
    const searchParams = { ...params, ...location };
    return this.searchEvents(searchParams);
  }

  /**
   * Search events by coordinates with radius
   */
  async searchEventsByCoordinates(
    coordinates: Coordinates,
    radius: number = 25,
    unit: 'miles' | 'km' = 'miles',
    params: Partial<EventSearchParams> = {}
  ): Promise<{
    events: Concert[];
    page: any;
  }> {
    const searchParams = {
      ...params,
      latlong: `${coordinates.latitude},${coordinates.longitude}`,
      radius: radius.toString(),
      unit
    };
    return this.searchEvents(searchParams);
  }

  /**
   * Search for venues
   */
  async searchVenues(params: VenueSearchParams = {}): Promise<{
    venues: Venue[];
    page: any;
  }> {
    const response: any = await this.makeRequest('/venues.json', params, undefined, 5 * 60 * 1000);
    
    const venues = response._embedded?.venues?.map((venue: TicketmasterVenue) =>
      this.transformVenue(venue)
    ) || [];

    return {
      venues,
      page: response.page || {
        size: venues.length,
        totalElements: venues.length,
        totalPages: 1,
        number: 0
      }
    };
  }

  /**
   * Get venue by ID
   */
  async getVenueById(venueId: string, locale?: string): Promise<Venue | null> {
    try {
      const params = locale ? { locale } : {};
      const response: any = await this.makeRequest(`/venues/${venueId}.json`, params, undefined, 10 * 60 * 1000);
      return this.transformVenue(response);
    } catch (error) {
      if (error instanceof TicketmasterError && error.statusCode === 404) {
        return null;
      }
      throw error;
    }
  }

  /**
   * Search for artists/attractions
   */
  async searchAttractions(params: AttractionSearchParams = {}): Promise<{
    attractions: Artist[];
    page: any;
  }> {
    const response: any = await this.makeRequest('/attractions.json', params, undefined, 5 * 60 * 1000);
    
    const attractions = response._embedded?.attractions?.map((attraction: TicketmasterAttraction) =>
      this.transformArtist(attraction)
    ) || [];

    return {
      attractions,
      page: response.page || {
        size: attractions.length,
        totalElements: attractions.length,
        totalPages: 1,
        number: 0
      }
    };
  }

  /**
   * Get attraction by ID
   */
  async getAttractionById(attractionId: string, locale?: string): Promise<Artist | null> {
    try {
      const params = locale ? { locale } : {};
      const response: any = await this.makeRequest(`/attractions/${attractionId}.json`, params, undefined, 10 * 60 * 1000);
      return this.transformArtist(response);
    } catch (error) {
      if (error instanceof TicketmasterError && error.statusCode === 404) {
        return null;
      }
      throw error;
    }
  }

  /**
   * Get classifications (genres, segments, etc.)
   */
  async getClassifications(params: { keyword?: string; size?: number; page?: number; sort?: string; locale?: string } = {}): Promise<any> {
    return this.makeRequest('/classifications.json', params, undefined, 60 * 60 * 1000); // Cache for 1 hour
  }

  /**
   * Transform Ticketmaster event to internal Concert format
   */
  transformTicketmasterEvent(event: TicketmasterEvent): Concert {
    const venue = event._embedded?.venues?.[0];
    const attractions = event._embedded?.attractions || [];

    return {
      id: event.id,
      name: event.name,
      description: event.info,
      date: event.dates?.start?.localDate || '',
      time: event.dates?.start?.localTime,
      venue: venue ? this.transformVenue(venue) : this.createEmptyVenue(),
      artists: attractions.map(attraction => this.transformArtist(attraction)),
      genres: this.extractGenres(event.classifications),
      images: this.processImages(event.images),
      ticketInfo: {
        status: event.dates?.status?.code || 'unknown',
        url: event.url,
        ticketLimit: event.ticketLimit?.info ? parseInt(event.ticketLimit.info) : undefined
      },
      priceRange: this.transformPriceRange(event.priceRanges),
      status: event.dates?.status?.code || 'unknown',
      url: event.url,
      seatmap: event.seatmap?.staticUrl,
      accessibility: this.extractAccessibility(event.accessibility),
      ageRestrictions: event.ageRestrictions?.legalAgeEnforced,
      classification: this.transformClassification(event.classifications?.[0]),
      promoter: this.transformPromoter(event.promoter || event.promoters?.[0]),
      pleaseNote: event.pleaseNote,
      distance: event.distance
    };
  }

  /**
   * Transform Ticketmaster venue to internal Venue format
   */
  transformVenue(venue: TicketmasterVenue): Venue {
    return {
      id: venue.id,
      name: venue.name,
      address: {
        line1: venue.address?.line1,
        line2: venue.address?.line2,
        line3: venue.address?.line3
      },
      city: venue.city?.name || '',
      state: venue.state?.name,
      country: venue.country?.name || venue.country?.countryCode || '',
      postalCode: venue.postalCode,
      timezone: venue.timezone,
      coordinates: venue.location ? {
        latitude: parseFloat(venue.location.latitude),
        longitude: parseFloat(venue.location.longitude)
      } : undefined,
      images: this.processImages(venue.images),
      boxOfficeInfo: venue.boxOfficeInfo ? {
        phoneNumberDetail: venue.boxOfficeInfo.phoneNumberDetail,
        openHoursDetail: venue.boxOfficeInfo.openHoursDetail,
        acceptedPaymentDetail: venue.boxOfficeInfo.acceptedPaymentDetail,
        willCallDetail: venue.boxOfficeInfo.willCallDetail
      } : undefined,
      parkingInfo: venue.parkingInfo,
      accessibleSeatingDetail: venue.accessibleSeatingDetail,
      generalInfo: venue.generalInfo ? {
        generalRule: venue.generalInfo.generalRule,
        childRule: venue.generalInfo.childRule
      } : undefined,
      url: venue.url,
      upcomingEvents: venue.upcomingEvents?._total,
      distance: venue.distance
    };
  }

  /**
   * Transform Ticketmaster attraction to internal Artist format
   */
  transformArtist(attraction: TicketmasterAttraction): Artist {
    return {
      id: attraction.id,
      name: attraction.name,
      url: attraction.url,
      images: this.processImages(attraction.images),
      classification: this.transformClassification(attraction.classifications?.[0]),
      upcomingEvents: attraction.upcomingEvents?._total,
      externalLinks: this.transformExternalLinks(attraction.externalLinks)
    };
  }

  /**
   * Process and optimize images
   */
  private processImages(images: any[] = []): Image[] {
    if (!images || !Array.isArray(images)) return [];

    return images
      .filter(img => img.url)
      .map(img => ({
        url: img.url,
        width: img.width,
        height: img.height,
        ratio: img.ratio,
        fallback: img.fallback
      }))
      .sort((a, b) => {
        // Prioritize by resolution
        const aRes = (a.width || 0) * (a.height || 0);
        const bRes = (b.width || 0) * (b.height || 0);
        return bRes - aRes;
      });
  }

  /**
   * Extract genres from classifications
   */
  private extractGenres(classifications: any[] = []): string[] {
    const genres = new Set<string>();
    
    classifications.forEach(classification => {
      if (classification.genre?.name) {
        genres.add(classification.genre.name);
      }
      if (classification.subGenre?.name) {
        genres.add(classification.subGenre.name);
      }
      if (classification.segment?.name) {
        genres.add(classification.segment.name);
      }
    });
    
    return Array.from(genres);
  }

  /**
   * Transform price range
   */
  private transformPriceRange(priceRanges: any[]): PriceRange | undefined {
    if (!priceRanges || priceRanges.length === 0) return undefined;
    
    const range = priceRanges[0];
    return {
      type: range.type || 'standard',
      currency: range.currency || 'USD',
      min: range.min || 0,
      max: range.max || 0
    };
  }

  /**
   * Extract accessibility information
   */
  private extractAccessibility(accessibility: any): string[] {
    if (!accessibility) return [];
    
    const features: string[] = [];
    
    if (accessibility.wheelchairAccessible) {
      features.push('Wheelchair Accessible');
    }
    if (accessibility.id) {
      features.push('Accessible Seating Available');
    }
    
    return features;
  }

  /**
   * Transform classification
   */
  private transformClassification(classification: any): Classification {
    if (!classification) {
      return { primary: true };
    }

    return {
      primary: classification.primary !== false,
      segment: classification.segment ? {
        id: classification.segment.id,
        name: classification.segment.name
      } : undefined,
      genre: classification.genre ? {
        id: classification.genre.id,
        name: classification.genre.name
      } : undefined,
      subGenre: classification.subGenre ? {
        id: classification.subGenre.id,
        name: classification.subGenre.name
      } : undefined,
      type: classification.type ? {
        id: classification.type.id,
        name: classification.type.name
      } : undefined,
      subType: classification.subType ? {
        id: classification.subType.id,
        name: classification.subType.name
      } : undefined,
      family: classification.family
    };
  }

  /**
   * Transform promoter information
   */
  private transformPromoter(promoter: any): Promoter | undefined {
    if (!promoter) return undefined;
    
    return {
      id: promoter.id,
      name: promoter.name,
      description: promoter.description
    };
  }

  /**
   * Transform external links
   */
  private transformExternalLinks(externalLinks: any): ExternalLinks | undefined {
    if (!externalLinks) return undefined;
    
    const links: ExternalLinks = {};
    
    Object.keys(externalLinks).forEach(platform => {
      if (Array.isArray(externalLinks[platform])) {
        links[platform as keyof ExternalLinks] = externalLinks[platform].map((link: any) => ({
          url: link.url
        }));
      }
    });
    
    return Object.keys(links).length > 0 ? links : undefined;
  }

  /**
   * Create empty venue for events without venue data
   */
  private createEmptyVenue(): Venue {
    return {
      id: '',
      name: 'TBA',
      address: {},
      city: '',
      country: '',
      images: []
    };
  }

  /**
   * Geocoding utility - convert address to coordinates
   */
  async geocodeAddress(params: GeocodingParams): Promise<Coordinates | null> {
    // Note: Ticketmaster doesn't provide a geocoding endpoint
    // This would typically use Google Maps, MapBox, or similar service
    // For now, return null and let the caller handle address-based searches
    console.warn('Geocoding not implemented. Use address-based search parameters instead.');
    return null;
  }

  /**
   * Calculate distance between two coordinates
   */
  static calculateDistance(
    coord1: Coordinates,
    coord2: Coordinates,
    unit: 'miles' | 'km' = 'miles'
  ): number {
    const R = unit === 'miles' ? 3959 : 6371; // Earth's radius
    const dLat = this.toRadians(coord2.latitude - coord1.latitude);
    const dLon = this.toRadians(coord2.longitude - coord1.longitude);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(coord1.latitude)) * Math.cos(this.toRadians(coord2.latitude)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  /**
   * Convert degrees to radians
   */
  private static toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  /**
   * Format date for API requests
   */
  static formatDateForAPI(date: Date): string {
    return date.toISOString().split('T')[0] + 'T00:00:00Z';
  }

  /**
   * Format price with currency
   */
  static formatPrice(amount: number, currency: string = 'USD'): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
  }

  /**
   * Normalize genre names
   */
  static normalizeGenre(genre: string): string {
    const genreMap: { [key: string]: string } = {
      'Rock': 'Rock',
      'Pop': 'Pop',
      'Hip-Hop/Rap': 'Hip-Hop',
      'R&B': 'R&B',
      'Country': 'Country',
      'Electronic/Dance': 'Electronic',
      'Jazz': 'Jazz',
      'Classical': 'Classical',
      'Alternative': 'Alternative',
      'Folk': 'Folk',
      'Blues': 'Blues',
      'Reggae': 'Reggae',
      'World': 'World Music',
      'Metal': 'Metal',
      'Punk': 'Punk'
    };
    
    return genreMap[genre] || genre;
  }

  /**
   * Format timezone-aware date
   */
  static formatEventDate(date: string, time?: string, timezone?: string): string {
    try {
      const dateStr = time ? `${date}T${time}:00` : `${date}T00:00:00`;
      const eventDate = new Date(dateStr);
      
      if (timezone) {
        return eventDate.toLocaleString('en-US', {
          timeZone: timezone,
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: time ? 'numeric' : undefined,
          minute: time ? '2-digit' : undefined,
          timeZoneName: 'short'
        });
      }
      
      return eventDate.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch (error) {
      return date;
    }
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.clear();
  }

  /**
   * Get cache statistics
   */
  getCacheStats(): { size: number } {
    return {
      size: this.cache.size()
    };
  }

  /**
   * Health check - verify API connectivity
   */
  async healthCheck(): Promise<boolean> {
    try {
      await this.searchEvents({ size: 1 });
      return true;
    } catch (error) {
      console.error('Ticketmaster API health check failed:', error);
      return false;
    }
  }
}

/**
 * Create and configure Ticketmaster API instance
 */
export function createTicketmasterAPI(apiKey: string, config?: Partial<TicketmasterConfig>): TicketmasterAPI {
  return new TicketmasterAPI({
    apiKey,
    ...config
  });
}

/**
 * Export error types for error handling
 */
export { TicketmasterError, RateLimitError, APIQuotaError };
export type { 
  Concert, 
  Venue, 
  Artist, 
  EventSearchParams, 
  VenueSearchParams, 
  AttractionSearchParams,
  Coordinates,
  GeocodingParams,
  TicketmasterConfig
};