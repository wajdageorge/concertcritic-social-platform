import supabase from './supabase'
import type { AuthResponse, AuthError, User } from '@supabase/supabase-js'

interface AuthResult {
  data: {
    user: User | null
    session: any
  } | null
  error: AuthError | null
}

interface ResetPasswordResult {
  data: {} | null
  error: AuthError | null
}

export async function signUp(email: string, password: string): Promise<AuthResult> {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    })

    if (error) {
      return { data: null, error }
    }

    return { data, error: null }
  } catch (error) {
    return {
      data: null,
      error: {
        message: 'An unexpected error occurred during sign up',
        name: 'UnknownError'
      } as AuthError
    }
  }
}

export async function signIn(email: string, password: string): Promise<AuthResult> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return { data: null, error }
    }

    return { data, error: null }
  } catch (error) {
    return {
      data: null,
      error: {
        message: 'An unexpected error occurred during sign in',
        name: 'UnknownError'
      } as AuthError
    }
  }
}

export async function signOut(): Promise<{ error: AuthError | null }> {
  try {
    const { error } = await supabase.auth.signOut()

    if (error) {
      return { error }
    }

    return { error: null }
  } catch (error) {
    return {
      error: {
        message: 'An unexpected error occurred during sign out',
        name: 'UnknownError'
      } as AuthError
    }
  }
}

export async function resetPassword(email: string): Promise<ResetPasswordResult> {
  try {
    const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })

    if (error) {
      return { data: null, error }
    }

    return { data, error: null }
  } catch (error) {
    return {
      data: null,
      error: {
        message: 'An unexpected error occurred during password reset',
        name: 'UnknownError'
      } as AuthError
    }
  }
}