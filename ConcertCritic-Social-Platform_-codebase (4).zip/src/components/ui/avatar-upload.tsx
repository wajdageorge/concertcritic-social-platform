"use client";

import React, { useState, useCallback, useRef } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Camera, X, Loader2, User, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

interface AvatarUploadProps {
  currentAvatar?: string;
  onFileSelect: (file: File) => void;
  onRemove: () => void;
  disabled?: boolean;
  isUploading?: boolean;
  error?: string;
  className?: string;
}

export const AvatarUpload = ({
  currentAvatar,
  onFileSelect,
  onRemove,
  disabled = false,
  isUploading = false,
  error,
  className
}: AvatarUploadProps) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): string | null => {
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    const maxSize = 5 * 1024 * 1024; // 5MB

    if (!validTypes.includes(file.type)) {
      return 'Please select a valid image file (JPEG, PNG, WebP, or GIF)';
    }

    if (file.size > maxSize) {
      return 'File size must be less than 5MB';
    }

    return null;
  };

  const handleFileSelect = useCallback((file: File) => {
    if (disabled || isUploading) return;

    const validationError = validateFile(file);
    if (validationError) {
      return;
    }

    // Create preview URL
    const previewUrl = URL.createObjectURL(file);
    setPreview(previewUrl);
    
    onFileSelect(file);
  }, [disabled, isUploading, onFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled && !isUploading) {
      setIsDragOver(true);
    }
  }, [disabled, isUploading]);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);

    if (disabled || isUploading) return;

    const files = Array.from(e.dataTransfer.files);
    const imageFile = files.find(file => file.type.startsWith('image/'));
    
    if (imageFile) {
      handleFileSelect(imageFile);
    }
  }, [disabled, isUploading, handleFileSelect]);

  const handleClick = useCallback(() => {
    if (!disabled && !isUploading) {
      fileInputRef.current?.click();
    }
  }, [disabled, isUploading]);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
    e.target.value = '';
  }, [handleFileSelect]);

  const handleRemove = useCallback(() => {
    if (preview) {
      URL.revokeObjectURL(preview);
      setPreview(null);
    }
    onRemove();
  }, [preview, onRemove]);

  const displayAvatar = preview || currentAvatar;
  const hasAvatar = Boolean(displayAvatar);

  return (
    <div className={cn("flex flex-col items-center space-y-4", className)}>
      {/* Avatar Preview */}
      <div className="relative">
        <Avatar className="w-24 h-24 border-2 border-border transition-all duration-200">
          <AvatarImage 
            src={displayAvatar} 
            alt="Avatar preview"
            className="object-cover"
          />
          <AvatarFallback className="bg-muted">
            <User className="w-8 h-8 text-muted-foreground" />
          </AvatarFallback>
        </Avatar>

        {/* Loading Overlay */}
        {isUploading && (
          <div className="absolute inset-0 bg-background/80 rounded-full flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        )}

        {/* Remove Button */}
        {hasAvatar && !isUploading && (
          <Button
            size="sm"
            variant="destructive"
            className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 shadow-lg"
            onClick={handleRemove}
            disabled={disabled}
          >
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>

      {/* Upload Area */}
      <div
        className={cn(
          "relative border-2 border-dashed rounded-lg p-6 text-center transition-all duration-200 cursor-pointer group",
          isDragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/50",
          error ? "border-destructive bg-destructive/5" : "",
          disabled || isUploading ? "opacity-50 cursor-not-allowed" : "hover:bg-muted/50"
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          onChange={handleFileInputChange}
          className="hidden"
          disabled={disabled || isUploading}
        />

        <div className="flex flex-col items-center space-y-2">
          <div className="p-2 bg-muted rounded-full group-hover:bg-primary/10 transition-colors">
            <Camera className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
          </div>
          
          <div className="space-y-1">
            <p className="text-sm font-medium text-foreground">
              {isDragOver ? "Drop image here" : "Upload avatar"}
            </p>
            <p className="text-xs text-muted-foreground">
              Drag & drop or click to browse
            </p>
            <p className="text-xs text-muted-foreground">
              JPEG, PNG, WebP, GIF (max 5MB)
            </p>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="flex items-center space-x-2 text-destructive">
          <X className="w-4 h-4" />
          <p className="text-sm">{error}</p>
        </div>
      )}

      {/* Upload Button Alternative */}
      <Button
        variant="outline"
        size="sm"
        onClick={handleClick}
        disabled={disabled || isUploading}
        className="min-w-32"
      >
        {isUploading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Uploading...
          </>
        ) : (
          <>
            <Upload className="w-4 h-4 mr-2" />
            Choose File
          </>
        )}
      </Button>
    </div>
  );
};