"use client";

import { signIn } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { FcGoogle } from "react-icons/fc";

export const GoogleSignInButton = () => {
  const handleGoogleSignIn = () => {
    signIn("google");
  };

  return (
    <Button
      variant="outline"
      className="w-full flex items-center gap-3 py-6 text-base font-medium transition-all duration-200 hover:bg-card hover:scale-[1.02] active:scale-[0.98]"
      onClick={handleGoogleSignIn}
    >
      <FcGoogle className="w-5 h-5" />
      Sign in with Google
    </Button>
  );
};