"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { AlertCircle, Loader2, UserPlus } from "lucide-react";
import { signUp } from "@/lib/auth-utils";
import supabase from "@/lib/supabase";

export const SignupForm = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    username: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const router = useRouter();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError("");
    if (success) setSuccess("");
  };

  const validateForm = () => {
    const { email, password, confirmPassword, username } = formData;

    if (!email || !password || !confirmPassword) {
      setError("Email, password, and password confirmation are required");
      return false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address");
      return false;
    }

    // Only validate username if it's provided
    if (username && username.length < 3) {
      setError("Username must be at least 3 characters long");
      return false;
    }

    if (username && !/^[a-zA-Z0-9_]+$/.test(username)) {
      setError("Username can only contain letters, numbers, and underscores");
      return false;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters long");
      return false;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return false;
    }

    return true;
  };

  const createProfile = async (userEmail: string, username?: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .insert({
          email: userEmail,
          username: username ? username.toLowerCase() : null,
          bio: null,
          location: null,
          avatar_url: null,
        });

      if (error) {
        console.error('Error creating profile:', error);
        throw error;
      }
    } catch (error) {
      console.error('Failed to create profile:', error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    setError("");
    setSuccess("");

    try {
      // Check if username is already taken (only if username provided)
      if (formData.username.trim()) {
        const usernameToCheck = formData.username.trim().toLowerCase();
        console.log('Checking username availability for:', usernameToCheck);
        
        const { data: existingProfiles, error: checkError } = await supabase
          .from('profiles')
          .select('username')
          .eq('username', usernameToCheck);

        console.log('Username check response:', { data: existingProfiles, error: checkError });

        if (checkError) {
          console.error('Error checking username:', checkError);
          throw new Error('Error checking username availability');
        }

        // If we get any results, the username is taken
        if (existingProfiles && existingProfiles.length > 0) {
          console.log('Username taken, found profiles:', existingProfiles);
          setError('Username already exists. Please choose a different username.');
          return;
        }

        console.log('Username available, proceeding with signup');
      }

      // Sign up the user
      const { data, error: authError } = await signUp(formData.email, formData.password);

      if (authError) {
        setError(authError.message);
        return;
      }

      if (data?.user?.email) {
        // Create profile automatically using the simplified schema (email-based)
        try {
          await createProfile(data.user.email, formData.username.trim() || undefined);
        } catch (profileError) {
          console.error('Profile creation failed but user was created:', profileError);
          // Don't fail the entire signup process if profile creation fails
          // The user can create profile later
        }

        if (data.user.email_confirmed_at) {
          // User is confirmed, redirect to app
          router.push("/app");
        } else {
          // User needs to confirm email
          setSuccess("Account created successfully! Please check your email to confirm your account before signing in.");
        }
      } else {
        setError("An unexpected error occurred during registration.");
      }
    } catch (err: any) {
      console.error('Signup error:', err);
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        {error && (
          <div className="flex items-center gap-2 p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="flex items-center gap-2 p-3 text-sm text-green-700 bg-green-50 border border-green-200 rounded-md">
            <div className="h-4 w-4 rounded-full bg-green-500 flex items-center justify-center">
              <div className="h-2 w-2 bg-white rounded-full"></div>
            </div>
            <span>{success}</span>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            placeholder="Enter your email"
            value={formData.email}
            onChange={handleInputChange}
            required
            disabled={loading}
            className="transition-colors focus:ring-primary"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="username">Username (Optional)</Label>
          <Input
            id="username"
            name="username"
            type="text"
            placeholder="Choose a username (you can set this later)"
            value={formData.username}
            onChange={handleInputChange}
            disabled={loading}
            className="transition-colors focus:ring-primary"
          />
          <p className="text-xs text-muted-foreground">
            You can skip this and set your username later in your profile.
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            name="password"
            type="password"
            placeholder="Create a password"
            value={formData.password}
            onChange={handleInputChange}
            required
            disabled={loading}
            className="transition-colors focus:ring-primary"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="confirmPassword">Confirm Password</Label>
          <Input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            placeholder="Confirm your password"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            required
            disabled={loading}
            className="transition-colors focus:ring-primary"
          />
        </div>

        <Button
          type="submit"
          className="w-full transition-all duration-200 hover:scale-[1.02]"
          disabled={loading}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating Account...
            </>
          ) : (
            <>
              <UserPlus className="mr-2 h-4 w-4" />
              Sign Up
            </>
          )}
        </Button>
      </form>
    </>
  );
};