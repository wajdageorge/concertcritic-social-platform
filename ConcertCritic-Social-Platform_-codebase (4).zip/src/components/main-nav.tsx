"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

export const MainNav = () => {
  const pathname = usePathname();

  const navItems = [
    { name: "Concerts", href: "/concerts" },
    { name: "Reviews", href: "/reviews" },
    { name: "Community", href: "/community" },
  ];

  return (
    <nav className="flex items-center justify-between p-4 bg-background border-b border-border">
      <Link href="/" className="text-xl font-bold text-primary mr-6">
        ConcertCritic
      </Link>
      <div className="flex items-center space-x-2">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              buttonVariants({ variant: "ghost" }),
              "text-foreground hover:bg-muted-foreground/10",
              pathname === item.href && "text-primary/80 bg-muted-foreground/10"
            )}
          >
            {item.name}
          </Link>
        ))}
      </div>
    </nav>
  );
};