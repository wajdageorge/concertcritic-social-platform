"use client";

import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Star,
  Music,
  Calendar,
  MapPin,
  Users,
  TrendingUp,
  Trophy,
  Award,
  Clock,
  Heart,
  MessageCircle,
  Eye,
  Music2,
  Guitar,
  Mic,
  Headphones,
  BarChart3,
  Target,
  Zap,
  Crown,
  Medal,
  Sparkles,
  ChevronRight,
  MoreHorizontal,
  UserPlus,
  PlusCircle,
  User
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { EditProfileModal } from "./edit-profile-modal";

export const ProfileAnalytics = () => {
  const { user, profile, profileLoading } = useAuth();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Show loading state while profile is being fetched
  if (profileLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  // If user doesn't have a profile, show create profile prompt
  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Create Your Profile</h3>
          <p className="text-muted-foreground mb-6">
            Welcome to Concert Critic! Set up your profile to start reviewing concerts and connecting with other music lovers.
          </p>
          <Button onClick={() => setIsEditModalOpen(true)} className="bg-primary hover:bg-primary/90">
            <User className="w-4 h-4 mr-2" />
            Create Profile
          </Button>
        </div>
      </div>
    );
  }

  // Default user data with profile information if available
  const userData = {
    profile: {
      name: profile?.username || user?.user_metadata?.full_name || user?.email?.split('@')[0] || "Music Critic",
      username: profile?.username ? `@${profile.username}` : `@${user?.email?.split('@')[0] || "musiccritic"}`,
      avatar: profile?.avatar_url || user?.user_metadata?.avatar_url || "",
      coverImage: "",
      joinDate: new Date(user?.created_at || Date.now()).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      location: profile?.location || "Add your location",
      bio: profile?.bio || "Music enthusiast ready to share concert experiences.",
      verified: false,
      followers: 0,
      following: 0,
    },
    stats: {
      totalReviews: 0,
      averageRating: 0,
      genresReviewed: 0,
      concertsAttended: 0,
      totalViews: 0,
      totalLikes: 0,
      reviewsThisMonth: 0,
      streakDays: 0,
    },
    achievements: [
      { id: 1, name: "First Review", description: "Write your first review", icon: Music, earned: false, rarity: "bronze" },
      { id: 2, name: "Music Explorer", description: "Review 3 different genres", icon: Music2, earned: false, rarity: "silver" },
      { id: 3, name: "Concert Lover", description: "Attend 10 concerts", icon: Guitar, earned: false, rarity: "gold" },
      { id: 4, name: "Critic's Choice", description: "Get featured review", icon: Award, earned: false, rarity: "platinum" },
      { id: 5, name: "Night Owl", description: "Review late night shows", icon: Clock, earned: false, rarity: "silver" },
      { id: 6, name: "Venue Expert", description: "Review 10+ venues", icon: MapPin, earned: false, rarity: "gold" },
    ],
    recentReviews: [],
    topVenues: [],
    genreBreakdown: [],
    activityData: Array.from({ length: 7 }, (_, i) => ({
      month: new Date(Date.now() - (6 - i) * 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short' }),
      reviews: 0
    })),
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "platinum": return "bg-gradient-to-r from-gray-300 to-white text-black";
      case "gold": return "bg-gradient-to-r from-yellow-400 to-yellow-600 text-black";
      case "silver": return "bg-gradient-to-r from-gray-400 to-gray-600 text-white";
      case "bronze": return "bg-gradient-to-r from-amber-600 to-amber-800 text-white";
      default: return "bg-gray-600 text-white";
    }
  };

  const handleEditProfile = () => {
    setIsEditModalOpen(true);
  };

  const handleProfileUpdated = () => {
    // Profile will be automatically refreshed via the auth context
    console.log('Profile updated successfully');
  };

  return (
    <div className="min-h-screen bg-background p-4 lg:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Profile Header */}
        <div className="relative">
          {/* Cover Image */}
          <div className="h-48 md:h-64 rounded-lg overflow-hidden bg-gradient-to-r from-primary/20 to-primary/10 relative">
            <div className="absolute inset-0 bg-black/20" />
            <div className="absolute bottom-4 left-4 right-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4">
                <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-background shadow-lg">
                  <AvatarImage src={userData.profile.avatar} alt={userData.profile.name} />
                  <AvatarFallback className="text-2xl font-bold bg-primary">
                    {userData.profile.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h1 className="text-2xl md:text-3xl font-bold text-white truncate">
                      {userData.profile.name}
                    </h1>
                    {userData.profile.verified && (
                      <Badge className="bg-primary text-primary-foreground">
                        <Trophy className="w-3 h-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                  </div>
                  <p className="text-white/80 text-sm mb-2">{userData.profile.username}</p>
                  <div className="flex items-center gap-4 text-white/70 text-sm">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {userData.profile.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Joined {userData.profile.joinDate}
                    </div>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  className="bg-background/80 backdrop-blur-sm hover:bg-background/90 transition-colors"
                  onClick={handleEditProfile}
                >
                  Edit Profile
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Bio & Follow Stats */}
        <Card>
          <CardContent className="p-6">
            <p className="text-foreground mb-4">{userData.profile.bio}</p>
            <div className="flex items-center gap-6 text-sm">
              <Button 
                variant="ghost" 
                className="p-0 h-auto text-left hover:bg-transparent"
                onClick={() => {/* TODO: Show followers modal */}}
              >
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="font-semibold">{userData.profile.followers.toLocaleString()}</span>
                  <span className="text-muted-foreground">Followers</span>
                </div>
              </Button>
              <Button 
                variant="ghost" 
                className="p-0 h-auto text-left hover:bg-transparent"
                onClick={() => {/* TODO: Show following modal */}}
              >
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{userData.profile.following}</span>
                  <span className="text-muted-foreground">Following</span>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Key Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-primary">{userData.stats.totalReviews}</p>
                  <p className="text-sm text-muted-foreground">Total Reviews</p>
                </div>
                <Music className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1">
                    <p className="text-2xl font-bold text-primary">{userData.stats.averageRating || "—"}</p>
                    {userData.stats.averageRating > 0 && <Star className="w-5 h-5 fill-primary text-primary" />}
                  </div>
                  <p className="text-sm text-muted-foreground">Avg Rating</p>
                </div>
                <Star className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-primary">{userData.stats.concertsAttended}</p>
                  <p className="text-sm text-muted-foreground">Concerts</p>
                </div>
                <Guitar className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-primary">{userData.stats.genresReviewed}</p>
                  <p className="text-sm text-muted-foreground">Genres</p>
                </div>
                <Music2 className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Empty State for New Users */}
        {userData.stats.totalReviews === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <PlusCircle className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Start Your Journey</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Welcome to Concert Critic! Write your first review to start building your music profile and unlock achievements.
              </p>
              <Button className="bg-primary hover:bg-primary/90">
                <PlusCircle className="w-4 h-4 mr-2" />
                Write Your First Review
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Achievements */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5" />
              Achievements & Milestones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {userData.achievements.map((achievement) => {
                const IconComponent = achievement.icon;
                return (
                  <div
                    key={achievement.id}
                    className={`p-4 rounded-lg border transition-all duration-200 ${
                      achievement.earned
                        ? 'bg-primary/5 border-primary/20 hover:bg-primary/10'
                        : 'bg-muted/50 border-muted opacity-50'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${getRarityColor(achievement.rarity)}`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium text-sm truncate">{achievement.name}</h3>
                          {achievement.earned && (
                            <Sparkles className="w-4 h-4 text-primary flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{achievement.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Review Activity Chart - Empty State */}
        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Review Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userData.activityData.map((item, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <span className="w-8 text-sm text-muted-foreground">{item.month}</span>
                    <div className="flex-1">
                      <Progress value={0} className="h-2" />
                    </div>
                    <span className="w-8 text-sm font-medium">{item.reviews}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6 text-center text-sm text-muted-foreground">
                Start writing reviews to see your activity chart
              </div>
            </CardContent>
          </Card>

          {/* Genre Breakdown - Empty State */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Music className="w-5 h-5" />
                Genre Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Music2 className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">
                  Write reviews across different genres to see your music taste distribution
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Edit Profile Modal - Always render for both create and edit cases */}
      <EditProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onProfileUpdated={handleProfileUpdated}
      />
    </div>
  );
};