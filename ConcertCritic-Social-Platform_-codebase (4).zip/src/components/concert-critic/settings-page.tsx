import React from "react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { User, Bell, Palette, Shield, HelpCircle, LogOut, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { signOut } from "@/lib/auth-utils";

export const SettingsPage = () => {
  const [theme, setTheme] = React.useState<string>("system");
  const [emailNotifs, setEmailNotifs] = React.useState<boolean>(true);
  const [pushNotifs, setPushNotifs] = React.useState<boolean>(false);
  const [highContrast, setHighContrast] = React.useState<boolean>(false);
  const [isSigningOut, setIsSigningOut] = React.useState<boolean>(false);
  const router = useRouter();

  // Example user
  const userProfile = {
    username: "concertfan42",
    email: "concertfan42@email.com",
  };

  // Handler stubs
  function handleEditProfile() {
    // Route to create/edit profile
    router.push("/profile/create");
  }

  const handleSignOut = async () => {
    setIsSigningOut(true);
    try {
      const { error } = await signOut();
      if (error) {
        console.error('Error signing out:', error);
        alert('Error signing out. Please try again.');
      } else {
        // Redirect to landing page
        router.push('/');
      }
    } catch (error) {
      console.error('Unexpected error during sign out:', error);
      alert('Unexpected error. Please try again.');
    } finally {
      setIsSigningOut(false);
    }
  };

  return (
    <section className="px-4 py-8 max-w-2xl mx-auto">
      <h2 className="text-h2 mb-2">Settings</h2>
      <p className="text-muted-foreground mb-6">
        Manage your Concert Critic account and preferences
      </p>

      {/* Edit Profile */}
      <section className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <User className="w-5 h-5 text-primary" />
          <h3 className="text-h4 text-primary">Edit Profile</h3>
        </div>
        <div className="grid grid-cols-[150px_1fr] items-center gap-4 mb-2">
          <Label htmlFor="username">Username</Label>
          <Input id="username" value={userProfile.username} readOnly disabled className="bg-muted" />
        </div>
        <div className="grid grid-cols-[150px_1fr] items-center gap-4">
          <Label htmlFor="email">Email</Label>
          <Input id="email" value={userProfile.email} readOnly disabled className="bg-muted" />
        </div>
        <Button size="sm" className="mt-4" onClick={handleEditProfile} variant="outline">Edit Profile</Button>
      </section>
      <Separator className="my-8" />

      {/* Notifications */}
      <section className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <Bell className="w-5 h-5 text-primary" />
          <h3 className="text-h4 text-primary">Notifications</h3>
        </div>
        <div className="flex items-center justify-between mb-4">
          <Label htmlFor="notif-email">Email notifications</Label>
          <Switch id="notif-email" checked={emailNotifs} onCheckedChange={setEmailNotifs} />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="notif-push">Push notifications</Label>
          <Switch id="notif-push" checked={pushNotifs} onCheckedChange={setPushNotifs} />
        </div>
        <p className="text-xs text-muted-foreground mt-2">Coming soon: customize notification types.</p>
      </section>
      <Separator className="my-8" />

      {/* Appearance */}
      <section className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <Palette className="w-5 h-5 text-primary" />
          <h3 className="text-h4 text-primary">Appearance</h3>
        </div>
        <RadioGroup
          value={theme}
          onValueChange={setTheme}
          className="flex gap-6"
          aria-label="Select theme"
        >
          <div className="flex items-center gap-2">
            <RadioGroupItem value="light" id="theme-light" />
            <Label htmlFor="theme-light" className="cursor-pointer">Light</Label>
          </div>
          <div className="flex items-center gap-2">
            <RadioGroupItem value="dark" id="theme-dark" />
            <Label htmlFor="theme-dark" className="cursor-pointer">Dark</Label>
          </div>
          <div className="flex items-center gap-2">
            <RadioGroupItem value="system" id="theme-system" />
            <Label htmlFor="theme-system" className="cursor-pointer">System</Label>
          </div>
        </RadioGroup>
        <div className="flex items-center justify-between mt-6">
          <Label htmlFor="high-contrast">High contrast mode</Label>
          <Switch id="high-contrast" checked={highContrast} onCheckedChange={setHighContrast} />
        </div>
        <p className="text-xs text-muted-foreground mt-2">Theme and accessibility preferences sync across devices.</p>
      </section>
      <Separator className="my-8" />

      {/* Privacy & Security */}
      <section className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <Shield className="w-5 h-5 text-primary" />
          <h3 className="text-h4 text-primary">Privacy & Security</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-2">Manage account privacy and security settings. (Coming soon)</p>
        <ul className="text-xs text-muted-foreground list-disc pl-5">
          <li>Change password</li>
          <li>Two-factor authentication</li>
          <li>Manage connected devices</li>
        </ul>
      </section>
      <Separator className="my-8" />

      {/* Support */}
      <section className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <HelpCircle className="w-5 h-5 text-primary" />
          <h3 className="text-h4 text-primary">Support</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-2">Need help or want to contact support? (Coming soon)</p>
        <ul className="text-xs text-muted-foreground list-disc pl-5">
          <li>Help Center</li>
          <li>Contact Us</li>
          <li>Report a problem</li>
        </ul>
      </section>
      <Separator className="my-8" />

      {/* Sign Out */}
      <section className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <LogOut className="w-5 h-5 text-destructive" />
          <h3 className="text-h4 text-destructive">Sign Out</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Sign out of your Concert Critic account on this device.
        </p>
        <Button 
          variant="destructive" 
          onClick={handleSignOut}
          disabled={isSigningOut}
          className="w-full md:w-auto"
        >
          {isSigningOut ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Signing Out...
            </>
          ) : (
            <>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </>
          )}
        </Button>
      </section>
    </section>
  );
};