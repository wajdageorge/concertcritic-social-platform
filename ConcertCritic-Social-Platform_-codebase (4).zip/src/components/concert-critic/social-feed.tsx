"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Heart, MessageCircle, Share2, Star, Filter, MoreHorizontal, PlusCircle } from "lucide-react";
import { useState } from "react";

interface PostData {
  id: string;
  user: {
    name: string;
    username: string;
    avatar: string;
  };
  venue: string;
  artist: string;
  rating: number;
  content: string;
  timestamp: string;
  likes: number;
  comments: number;
  shares: number;
  isLiked: boolean;
  genre: string;
  media?: {
    url: string;
    type: 'image' | 'video';
    name?: string;
  }[];
}

const StarRating = ({ rating }: { rating: number }) => {
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${
            i < rating 
              ? "fill-yellow-400 text-yellow-400" 
              : "text-gray-600"
          }`}
        />
      ))}
      <span className="text-sm text-secondary-foreground ml-1">
        {rating}/5
      </span>
    </div>
  );
};

interface SocialFeedProps {
  onNavigateToAddReview?: () => void;
}

export const SocialFeed = ({ onNavigateToAddReview }: SocialFeedProps) => {
  const [posts, setPosts] = useState<PostData[]>([]);
  const [filter, setFilter] = useState<string>("All");

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            isLiked: !post.isLiked,
            likes: post.isLiked ? post.likes - 1 : post.likes + 1
          }
        : post
    ));
  };

  const handleWriteFirstReview = () => {
    if (onNavigateToAddReview) {
      onNavigateToAddReview();
    }
  };

  const genres = ["All"];
  const filteredPosts = posts;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-2xl mx-auto p-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground">Feed</h1>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Filter className="w-4 h-4" />
                  {filter}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {genres.map((genre) => (
                  <DropdownMenuItem 
                    key={genre}
                    onClick={() => setFilter(genre)}
                    className={filter === genre ? "bg-accent" : ""}
                  >
                    {genre}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Feed */}
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {filteredPosts.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <PlusCircle className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Welcome to Concert Critic!</h3>
            <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
              Your feed is empty. Start by writing your first concert review to see content from other music lovers in your network.
            </p>
            <Button className="bg-primary hover:bg-primary/90" onClick={handleWriteFirstReview}>
              <PlusCircle className="w-4 h-4 mr-2" />
              Write Your First Review
            </Button>
          </div>
        ) : (
          filteredPosts.map((post) => (
            <Card key={post.id} className="bg-card border-border">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={post.user.avatar} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {post.user.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-foreground">{post.user.name}</p>
                      <p className="text-sm text-muted-foreground">{post.user.username}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
                <div className="mt-3 space-y-2">
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="font-medium text-primary">{post.artist}</span>
                    <span className="text-muted-foreground">at</span>
                    <span className="font-medium text-foreground">{post.venue}</span>
                    <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                      {post.genre}
                    </span>
                  </div>
                  <StarRating rating={post.rating} />
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-foreground leading-relaxed mb-4">
                  {post.content}
                </p>
                {/* Media attachments */}
                {post.media && post.media.length > 0 && (
                  <div className="flex flex-wrap gap-4 mb-4">
                    {post.media.map((item, idx) =>
                      item.type === "image" ? (
                        <img
                          key={idx}
                          src={item.url}
                          alt={item.name || `media-${idx}`}
                          className="h-28 w-36 rounded-lg object-cover border"
                        />
                      ) : (
                        <video
                          key={idx}
                          controls
                          src={item.url}
                          className="h-28 w-48 rounded-lg border bg-black"
                        />
                      )
                    )}
                  </div>
                )}
                <div className="flex items-center justify-between text-muted-foreground border-t border-border pt-3">
                  <span className="text-sm">{post.timestamp}</span>
                  <div className="flex items-center gap-6">
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`gap-2 h-8 px-2 transition-colors ${
                        post.isLiked 
                          ? "text-red-500 hover:text-red-600" 
                          : "hover:text-red-500"
                      }`}
                      onClick={() => handleLike(post.id)}
                    >
                      <Heart className={`w-4 h-4 ${post.isLiked ? "fill-current" : ""}`} />
                      <span className="text-sm">{post.likes}</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-2 h-8 px-2 hover:text-primary"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-sm">{post.comments}</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-2 h-8 px-2 hover:text-primary"
                    >
                      <Share2 className="w-4 h-4" />
                      <span className="text-sm">{post.shares}</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};