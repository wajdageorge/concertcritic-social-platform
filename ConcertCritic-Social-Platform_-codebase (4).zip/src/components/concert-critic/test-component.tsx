"use client";

import React from 'react';

interface TestComponentProps {
  className?: string;
}

export const TestComponent: React.FC<TestComponentProps> = ({ className }) => {
  return (
    <div className={className}>
      Test Component
    </div>
  );
};