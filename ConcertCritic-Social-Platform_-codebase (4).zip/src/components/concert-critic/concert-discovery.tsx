"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, MapPin, Calendar, Star, Clock, ExternalLink, Music, Ticket, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface Concert {
  id: string;
  title: string;
  artist: string;
  venue: string;
  location: string;
  date: string;
  time?: string;
  price?: {
    min: number;
    max: number;
    currency: string;
  };
  image?: string;
  description?: string;
  ticketUrl: string;
  status: 'on_sale' | 'sold_out' | 'cancelled' | 'postponed' | 'rescheduled';
  coordinates?: {
    lat: number;
    lng: number;
  };
  genres?: string[];
}

interface ConcertDiscoveryProps {
  onNavigateToAddReview?: () => void;
}

export const ConcertDiscovery = ({ onNavigateToAddReview }: ConcertDiscoveryProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [activeTab, setActiveTab] = useState('upcoming');
  const [concerts, setConcerts] = useState<Concert[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({
    page: 0,
    totalPages: 0,
    total: 0
  });

  const genres = [
    'all', 'Rock', 'Pop', 'Hip-Hop', 'Electronic', 'Country', 'Jazz', 
    'Classical', 'R&B', 'Alternative', 'Metal', 'Indie', 'Folk'
  ];
  
  const locations = [
    'all', 'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 
    'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose'
  ];

  // Fetch concerts from API
  const fetchConcerts = async (params: {
    keyword?: string;
    location?: string;
    genre?: string;
    page?: number;
  } = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const searchParams = new URLSearchParams();
      
      if (params.keyword) searchParams.set('keyword', params.keyword);
      if (params.location && params.location !== 'all') searchParams.set('location', params.location);
      if (params.genre && params.genre !== 'all') searchParams.set('genre', params.genre);
      searchParams.set('page', (params.page || 0).toString());
      searchParams.set('limit', '20');
      
      const apiUrl = `/api/events?${searchParams.toString()}`;
      console.log('Fetching concerts from:', apiUrl);
      
      const response = await fetch(apiUrl);
      
      console.log('API Response status:', response.status);
      console.log('API Response headers:', Object.fromEntries(response.headers.entries()));
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Response error text:', errorText);
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('API Response data:', data);
      
      if (data.error) {
        throw new Error(data.error);
      }
      
      setConcerts(data.data || []);
      setPagination({
        page: data.pagination?.page || 0,
        totalPages: data.pagination?.totalPages || 0,
        total: data.pagination?.total || 0
      });
      
    } catch (err) {
      console.error('Failed to fetch concerts:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch concerts');
      setConcerts([]);
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchConcerts();
  }, []);

  // Search handler
  const handleSearch = () => {
    fetchConcerts({
      keyword: searchTerm,
      location: selectedLocation,
      genre: selectedGenre,
      page: 0
    });
  };

  // Filter change handlers
  useEffect(() => {
    if (selectedGenre !== 'all' || selectedLocation !== 'all') {
      fetchConcerts({
        keyword: searchTerm,
        location: selectedLocation,
        genre: selectedGenre,
        page: 0
      });
    }
  }, [selectedGenre, selectedLocation]);

  const handleAddConcert = () => {
    if (onNavigateToAddReview) {
      onNavigateToAddReview();
    }
  };

  const handleGetTickets = (concert: Concert) => {
    if (concert.ticketUrl) {
      window.open(concert.ticketUrl, '_blank');
    } else {
      alert(`Ticket purchasing will be available soon for ${concert.artist} at ${concert.venue}!`);
    }
  };

  const handleLoadMore = () => {
    fetchConcerts({
      keyword: searchTerm,
      location: selectedLocation,
      genre: selectedGenre,
      page: pagination.page + 1
    });
  };

  const formatPrice = (price: { min: number; max: number; currency: string }) => {
    if (price.min === price.max) {
      return `$${price.min}`;
    }
    return `$${price.min} - $${price.max}`;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Concert Discovery</h1>
        <p className="text-muted-foreground">Find and review the best live music in your area</p>
      </div>

      {/* Search and Filters */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search artists, venues, or events..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="pl-10"
            />
          </div>
          <Button onClick={handleSearch} className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            Search
          </Button>
        </div>

        <div className="flex flex-wrap gap-4">
          <Select value={selectedGenre} onValueChange={setSelectedGenre}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select genre" />
            </SelectTrigger>
            <SelectContent>
              {genres.map(genre => (
                <SelectItem key={genre} value={genre}>
                  {genre === 'all' ? 'All Genres' : genre}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedLocation} onValueChange={setSelectedLocation}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select location" />
            </SelectTrigger>
            <SelectContent>
              {locations.map(location => (
                <SelectItem key={location} value={location}>
                  {location === 'all' ? 'All Locations' : location}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Error State */}
      {error && (
        <Card className="mb-8 border-destructive">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-destructive">
              <ExternalLink className="w-5 h-5" />
              <div>
                <h3 className="font-semibold">Unable to load events</h3>
                <p className="text-sm">{error}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-2"
                  onClick={() => fetchConcerts()}
                >
                  Try Again
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Map Placeholder */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="bg-muted rounded-lg h-64 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-12 h-12 text-primary mx-auto mb-2" />
              <h3 className="text-lg font-semibold mb-1">Interactive Map Coming Soon</h3>
              <p className="text-muted-foreground">View concerts on a map to find events near you</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Upcoming Events
          </TabsTrigger>
          <TabsTrigger value="popular" className="flex items-center gap-2">
            <Star className="w-4 h-4" />
            Popular
          </TabsTrigger>
          <TabsTrigger value="near-me" className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Near Me
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="mt-6">
          {loading && concerts.length === 0 ? (
            <LoadingState />
          ) : concerts.length === 0 ? (
            <EmptyState onAddConcert={handleAddConcert} />
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {concerts.map(concert => (
                  <ConcertCard 
                    key={concert.id} 
                    concert={concert} 
                    onGetTickets={handleGetTickets} 
                    formatPrice={formatPrice}
                  />
                ))}
              </div>
              
              {/* Pagination */}
              {pagination.totalPages > 1 && (
                <div className="flex justify-center items-center gap-4 pt-8">
                  <div className="text-sm text-muted-foreground">
                    Showing {concerts.length} of {pagination.total} events
                  </div>
                  {pagination.page < pagination.totalPages - 1 && (
                    <Button 
                      onClick={handleLoadMore} 
                      disabled={loading}
                      variant="outline"
                    >
                      {loading ? 'Loading...' : 'Load More'}
                    </Button>
                  )}
                </div>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent value="popular" className="mt-6">
          {loading && concerts.length === 0 ? (
            <LoadingState />
          ) : concerts.length === 0 ? (
            <EmptyState onAddConcert={handleAddConcert} />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {concerts.map(concert => (
                <ConcertCard 
                  key={concert.id} 
                  concert={concert} 
                  onGetTickets={handleGetTickets}
                  formatPrice={formatPrice}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="near-me" className="mt-6">
          {loading && concerts.length === 0 ? (
            <LoadingState />
          ) : concerts.length === 0 ? (
            <EmptyState onAddConcert={handleAddConcert} />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {concerts.map(concert => (
                <ConcertCard 
                  key={concert.id} 
                  concert={concert} 
                  onGetTickets={handleGetTickets}
                  formatPrice={formatPrice}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

const LoadingState = () => (
  <div className="text-center py-16">
    <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
    <h3 className="text-lg font-semibold mb-2">Loading concerts...</h3>
    <p className="text-muted-foreground">Finding the best live music events for you</p>
  </div>
);

const EmptyState = ({ onAddConcert }: { onAddConcert?: () => void }) => (
  <div className="text-center py-16">
    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
      <Music className="w-8 h-8 text-primary" />
    </div>
    <h3 className="text-xl font-semibold mb-2">No concerts found</h3>
    <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
      Try adjusting your search criteria or check back later for new events.
    </p>
    <Button variant="outline" onClick={onAddConcert}>
      <Plus className="w-4 h-4 mr-2" />
      Add a Concert Review
    </Button>
  </div>
);

const ConcertCard = ({ 
  concert, 
  onGetTickets,
  formatPrice 
}: { 
  concert: Concert; 
  onGetTickets: (concert: Concert) => void;
  formatPrice: (price: { min: number; max: number; currency: string }) => string;
}) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: Concert['status']) => {
    const variants = {
      on_sale: 'default',
      sold_out: 'destructive',
      cancelled: 'destructive',
      postponed: 'secondary',
      rescheduled: 'secondary'
    } as const;

    const labels = {
      on_sale: 'On Sale',
      sold_out: 'Sold Out',
      cancelled: 'Cancelled',
      postponed: 'Postponed',
      rescheduled: 'Rescheduled'
    };

    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    );
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 group">
      <div className="aspect-[4/3] bg-muted relative overflow-hidden">
        {concert.image ? (
          <img 
            src={concert.image} 
            alt={concert.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/20 via-secondary/20 to-primary/30 flex items-center justify-center">
            <Music className="w-16 h-16 text-primary/60" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        <div className="absolute bottom-4 left-4 text-white">
          <h3 className="text-xl font-bold mb-1">{concert.artist}</h3>
          {concert.genres && concert.genres.length > 0 && (
            <Badge variant="secondary" className="mb-2">
              {concert.genres[0]}
            </Badge>
          )}
        </div>
        <div className="absolute top-4 right-4">
          {getStatusBadge(concert.status)}
        </div>
      </div>
      
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <h4 className="font-semibold text-lg">{concert.title}</h4>
            <p className="text-muted-foreground">{concert.venue}</p>
            <div className="flex items-center gap-2 text-muted-foreground text-sm mt-1">
              <MapPin className="w-4 h-4" />
              <span>{concert.location}</span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />
              <span>{formatDate(concert.date)}</span>
            </div>
            {concert.time && (
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                <span>{concert.time}</span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div>
              {concert.price ? (
                <span className="text-lg font-bold text-primary">
                  {formatPrice(concert.price)}
                </span>
              ) : (
                <span className="text-sm text-muted-foreground">Price TBA</span>
              )}
            </div>
            <Button 
              className="flex items-center gap-2 bg-primary hover:bg-primary/90"
              onClick={() => onGetTickets(concert)}
              disabled={concert.status === 'sold_out' || concert.status === 'cancelled'}
            >
              <Ticket className="w-4 h-4" />
              {concert.status === 'sold_out' ? 'Sold Out' : 
               concert.status === 'cancelled' ? 'Cancelled' : 'Get Tickets'}
              {concert.status === 'on_sale' && <ExternalLink className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ConcertDiscovery;