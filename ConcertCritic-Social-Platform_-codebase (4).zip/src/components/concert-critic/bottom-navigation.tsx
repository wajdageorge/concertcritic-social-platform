"use client";

import { Home, Search, PlusCircle, User, Settings, Users } from "lucide-react";
import { cn } from "@/lib/utils";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  isCenter?: boolean;
}

export const BottomNavigation = ({ activeTab, onTabChange }: BottomNavigationProps) => {
  const navItems: NavItem[] = [
    {
      id: "home",
      label: "Home",
      icon: Home,
    },
    {
      id: "search",
      label: "Search",
      icon: Users,
    },
    {
      id: "add",
      label: "Add Review",
      icon: PlusCircle,
      isCenter: true,
    },
    {
      id: "discover",
      label: "Discover",
      icon: Search,
    },
    {
      id: "profile",
      label: "Profile",
      icon: User,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border">
      <div className="flex items-center justify-between px-4 py-2 max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          if (item.isCenter) {
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "flex flex-col items-center justify-center",
                  "w-14 h-14 rounded-full",
                  "bg-primary text-primary-foreground shadow-lg",
                  "transform transition-all duration-200 ease-in-out",
                  "hover:scale-110 hover:shadow-xl",
                  "active:scale-95",
                  "relative -top-2"
                )}
                aria-label={item.label}
              >
                <Icon className="w-6 h-6" />
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={cn(
                "flex flex-col items-center justify-center",
                "min-w-[64px] py-2 px-2",
                "transition-all duration-200 ease-in-out",
                "hover:bg-muted/50 rounded-lg",
                "active:scale-95"
              )}
              aria-label={item.label}
            >
              <Icon
                className={cn(
                  "w-6 h-6 mb-1 transition-colors duration-200",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}
              />
              <span
                className={cn(
                  "text-xs font-medium transition-colors duration-200",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};