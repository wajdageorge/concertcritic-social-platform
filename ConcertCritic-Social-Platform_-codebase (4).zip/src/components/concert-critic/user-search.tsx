"use client";

import { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, Users, UserPlus, UserMinus, MapPin, Calendar, Loader2 } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { searchUsers, followUser, unfollowUser, isFollowing, type UserProfile } from '@/lib/follows-utils';

export const UserSearch = () => {
  const { user: currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [following, setFollowing] = useState<Record<string, boolean>>({});
  const [hasSearched, setHasSearched] = useState(false);
  const [followLoading, setFollowLoading] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery.trim()) {
        performSearch(searchQuery);
      } else {
        setSearchResults([]);
        setHasSearched(false);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  const performSearch = async (query: string) => {
    setLoading(true);
    setHasSearched(true);
    
    try {
      const { data, error } = await searchUsers(query);
      
      if (error) {
        console.error('Search error:', error);
        setSearchResults([]);
        return;
      }

      if (data) {
        setSearchResults(data.users);
        
        // Check follow status for each user
        const followingState: Record<string, boolean> = {};
        const followStatus = await Promise.all(
          data.users.map(async (user) => {
            if (!currentUser || currentUser.id === user.id) return { userId: user.id, isFollowing: false };
            
            const { data: isFollowingUser } = await isFollowing(user.id);
            return { userId: user.id, isFollowing: isFollowingUser || false };
          })
        );
        
        followStatus.forEach(({ userId, isFollowing: isFollowingUser }) => {
          followingState[userId] = isFollowingUser;
        });
        
        setFollowing(followingState);
      }
    } catch (error) {
      console.error('Search failed:', error);
      setSearchResults([]);
    } finally {
      setLoading(false);
    }
  };

  const handleFollowToggle = async (userId: string) => {
    if (!currentUser) return;
    
    setFollowLoading(prev => ({ ...prev, [userId]: true }));
    
    try {
      const isCurrentlyFollowing = following[userId];
      
      if (isCurrentlyFollowing) {
        const { error } = await unfollowUser(userId);
        if (error) {
          console.error('Unfollow error:', error);
          return;
        }
      } else {
        const { error } = await followUser(userId);
        if (error) {
          console.error('Follow error:', error);
          return;
        }
      }
      
      // Update following state
      setFollowing(prev => ({ ...prev, [userId]: !isCurrentlyFollowing }));
      
      // Update the user's follower count in search results
      setSearchResults(prev => prev.map(user => 
        user.id === userId 
          ? { 
              ...user, 
              follower_count: isCurrentlyFollowing 
                ? user.follower_count - 1 
                : user.follower_count + 1
            }
          : user
      ));
      
    } catch (error) {
      console.error('Follow toggle failed:', error);
    } finally {
      setFollowLoading(prev => ({ ...prev, [userId]: false }));
    }
  };

  const getInitials = (displayName: string) => {
    return displayName
      .split(' ')
      .map(name => name[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatJoinDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      year: 'numeric' 
    });
  };

  const EmptySearchState = () => (
    <div className="flex flex-col items-center justify-center py-16 px-4">
      <div className="w-24 h-24 rounded-full bg-muted/20 flex items-center justify-center mb-6">
        <Users className="w-12 h-12 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold mb-2">Find Music Lovers</h3>
      <p className="text-muted-foreground text-center max-w-md">
        Start typing to search for users by username or display name. Connect with fellow concert enthusiasts!
      </p>
    </div>
  );

  const NoResultsState = () => (
    <div className="flex flex-col items-center justify-center py-16 px-4">
      <div className="w-24 h-24 rounded-full bg-muted/20 flex items-center justify-center mb-6">
        <Search className="w-12 h-12 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold mb-2">No Users Found</h3>
      <p className="text-muted-foreground text-center max-w-md">
        We couldn't find any users matching "{searchQuery}". Try a different search term.
      </p>
    </div>
  );

  const LoadingState = () => (
    <div className="flex items-center justify-center py-16">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
      <span className="ml-3 text-muted-foreground">Searching users...</span>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Sticky Header with Search */}
      <div className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
        <div className="container mx-auto px-4 py-6">
          <div className="relative max-w-2xl mx-auto">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              placeholder="Search users by username or display name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-3 text-lg bg-card/50 border-border/50 focus:bg-card focus:border-primary/50 transition-all duration-200"
            />
          </div>
        </div>
      </div>

      {/* Results Area */}
      <div className="container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          {loading && <LoadingState />}
          
          {!loading && !hasSearched && <EmptySearchState />}
          
          {!loading && hasSearched && searchResults.length === 0 && <NoResultsState />}
          
          {!loading && searchResults.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-6">
                <Users className="w-4 h-4" />
                <span>{searchResults.length} user{searchResults.length !== 1 ? 's' : ''} found</span>
              </div>
              
              {searchResults.map((user) => (
                <Card key={user.id} className="p-6 hover:shadow-lg transition-all duration-200 hover:bg-card/80 group">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-14 h-14 border-2 border-border group-hover:border-primary/20 transition-colors">
                      {user.avatar_url ? (
                        <img src={user.avatar_url} alt={user.display_name || user.username} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-lg">
                          {getInitials(user.display_name || user.username)}
                        </div>
                      )}
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4">
                        <div className="min-w-0 flex-1">
                          <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                            {user.display_name || user.username}
                          </h3>
                          <p className="text-muted-foreground text-sm">@{user.username}</p>
                          
                          {user.bio && (
                            <p className="text-foreground/80 mt-2 text-sm leading-relaxed line-clamp-2">
                              {user.bio}
                            </p>
                          )}
                          
                          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              <span>Joined {formatJoinDate(user.created_at)}</span>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-3 mt-3">
                            <Badge variant="secondary" className="text-xs">
                              {user.follower_count?.toLocaleString() || 0} followers
                            </Badge>
                          </div>
                        </div>
                        
                        {currentUser && currentUser.id !== user.id && (
                          <Button
                            onClick={() => handleFollowToggle(user.id)}
                            variant={following[user.id] ? "outline" : "default"}
                            size="sm"
                            className="shrink-0 transition-all duration-200 hover:scale-105"
                            disabled={followLoading[user.id]}
                          >
                            {followLoading[user.id] ? (
                              <Loader2 className="w-4 h-4 animate-spin mr-2" />
                            ) : following[user.id] ? (
                              <>
                                <UserMinus className="w-4 h-4 mr-2" />
                                Following
                              </>
                            ) : (
                              <>
                                <UserPlus className="w-4 h-4 mr-2" />
                                Follow
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};