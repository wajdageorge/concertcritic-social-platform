"use client";

import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Star, 
  StarHalf,
  Camera, 
  Tag, 
  Send, 
  Search, 
  Calendar, 
  MapPin, 
  Music, 
  Users, 
  Car, 
  VolumeX, 
  Eye,
  Heart,
  Coffee,
  Navigation,
  Upload,
  X,
  Check,
  CheckCircle
} from 'lucide-react';

interface ConcertFormData {
  artist: string;
  venue: string;
  date: string;
  ratings: {
    overall: number;
    soundQuality: number;
    performance: number;
    valueForMoney: number;
  };
  venueRatings?: {
    soundQuality: number;
    sightLines: number;
    accessibility: number;
    amenities: number;
    staffFriendliness: number;
    locationParking: number;
  };
  reviewText: string;
  photos: File[];
  tags: string[];
}

interface VenueData {
  id: string;
  name: string;
  location: string;
  capacity: string;
}

interface ConcertData {
  id: string;
  artist: string;
  venue: string;
  date: string;
}

const SAMPLE_VENUES: VenueData[] = [
  { id: '1', name: 'Madison Square Garden', location: 'New York, NY', capacity: '20,789' },
  { id: '2', name: 'The Fillmore', location: 'San Francisco, CA', capacity: '1,315' },
  { id: '3', name: 'Red Rocks Amphitheatre', location: 'Morrison, CO', capacity: '9,525' },
  { id: '4', name: 'The Troubadour', location: 'West Hollywood, CA', capacity: '400' },
];

const SAMPLE_CONCERTS: ConcertData[] = [
  { id: '1', artist: 'Arctic Monkeys', venue: 'Madison Square Garden', date: '2024-01-15' },
  { id: '2', artist: 'Billie Eilish', venue: 'The Fillmore', date: '2024-01-20' },
  { id: '3', artist: 'Glass Animals', venue: 'Red Rocks Amphitheatre', date: '2024-01-25' },
  { id: '4', artist: 'Phoebe Bridgers', venue: 'The Troubadour', date: '2024-01-30' },
];

const GENRE_TAGS = [
  'Rock', 'Pop', 'Hip Hop', 'Electronic', 'Indie', 'Jazz', 
  'Classical', 'Country', 'R&B', 'Alternative', 'Metal', 'Folk'
];

const MOOD_TAGS = [
  'Energetic', 'Chill', 'Emotional', 'Fun', 'Intense', 'Uplifting',
  'Dark', 'Romantic', 'Nostalgic', 'Peaceful', 'Wild', 'Intimate'
];

const StarRating: React.FC<{
  rating: number;
  onRatingChange: (rating: number) => void;
  size?: 'sm' | 'md' | 'lg';
}> = ({ rating, onRatingChange, size = 'md' }) => {
  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-5 w-5',
    lg: 'h-6 w-6'
  };

  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => onRatingChange(star)}
          className={`${sizeClasses[size]} text-primary hover:scale-110 transition-transform`}
        >
          <Star 
            className={`${sizeClasses[size]} ${
              star <= rating ? 'fill-current' : 'fill-none'
            }`}
          />
        </button>
      ))}
    </div>
  );
};

const TagSelector: React.FC<{
  selectedTags: string[];
  availableTags: string[];
  onTagToggle: (tag: string) => void;
  title: string;
}> = ({ selectedTags, availableTags, onTagToggle, title }) => {
  return (
    <div className="space-y-3">
      <Label className="text-sm font-medium">{title}</Label>
      <div className="flex flex-wrap gap-2">
        {availableTags.map((tag) => (
          <Badge
            key={tag}
            variant={selectedTags.includes(tag) ? "default" : "secondary"}
            className={`cursor-pointer transition-colors ${
              selectedTags.includes(tag) 
                ? 'bg-primary text-primary-foreground' 
                : 'hover:bg-primary/20'
            }`}
            onClick={() => onTagToggle(tag)}
          >
            <Tag className="h-3 w-3 mr-1" />
            {tag}
          </Badge>
        ))}
      </div>
    </div>
  );
};

interface ReviewComposerProps {
  onReviewSubmitted?: () => void;
}

export const ReviewComposer: React.FC<ReviewComposerProps> = ({ onReviewSubmitted }) => {
  const [formData, setFormData] = useState<ConcertFormData>({
    artist: '',
    venue: '',
    date: '',
    ratings: {
      overall: 0,
      soundQuality: 0,
      performance: 0,
      valueForMoney: 0,
    },
    reviewText: '',
    photos: [],
    tags: [],
  });

  const [includeVenueRating, setIncludeVenueRating] = useState(false);
  const [searchResults, setSearchResults] = useState<{
    concerts: ConcertData[];
    venues: VenueData[];
  }>({ concerts: [], venues: [] });
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [characterCount, setCharacterCount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    setCharacterCount(formData.reviewText.length);
  }, [formData.reviewText]);

  useEffect(() => {
    if (searchQuery.length > 2) {
      const filteredConcerts = SAMPLE_CONCERTS.filter(
        concert => 
          concert.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
          concert.venue.toLowerCase().includes(searchQuery.toLowerCase())
      );
      const filteredVenues = SAMPLE_VENUES.filter(
        venue => venue.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSearchResults({ concerts: filteredConcerts, venues: filteredVenues });
      setShowSearch(true);
    } else {
      setShowSearch(false);
    }
  }, [searchQuery]);

  const updateFormData = (field: keyof ConcertFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateRating = (category: keyof ConcertFormData['ratings'], rating: number) => {
    setFormData(prev => ({
      ...prev,
      ratings: { ...prev.ratings, [category]: rating }
    }));
  };

  const updateVenueRating = (category: keyof NonNullable<ConcertFormData['venueRatings']>, rating: number) => {
    setFormData(prev => ({
      ...prev,
      venueRatings: {
        ...prev.venueRatings,
        [category]: rating
      } as NonNullable<ConcertFormData['venueRatings']>
    }));
  };

  const handleToggleVenueRating = (enabled: boolean) => {
    setIncludeVenueRating(enabled);
    if (enabled && !formData.venueRatings) {
      setFormData(prev => ({
        ...prev,
        venueRatings: {
          soundQuality: 0,
          sightLines: 0,
          accessibility: 0,
          amenities: 0,
          staffFriendliness: 0,
          locationParking: 0,
        }
      }));
    } else if (!enabled) {
      setFormData(prev => ({
        ...prev,
        venueRatings: undefined
      }));
    }
  };

  const handleTagToggle = (tag: string) => {
    setSelectedTags(prev => {
      const newTags = prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag];
      setFormData(prevForm => ({ ...prevForm, tags: newTags }));
      return newTags;
    });
  };

  const handleConcertSelect = (concert: ConcertData) => {
    setFormData(prev => ({
      ...prev,
      artist: concert.artist,
      venue: concert.venue,
      date: concert.date
    }));
    setSearchQuery('');
    setShowSearch(false);
  };

  const handleVenueSelect = (venue: VenueData) => {
    setFormData(prev => ({ ...prev, venue: venue.name }));
    setSearchQuery('');
    setShowSearch(false);
  };

  const validateForm = () => {
    return formData.artist && formData.venue && formData.date && 
           formData.ratings.overall > 0 && formData.reviewText.length >= 50;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      alert('Please fill in all required fields and ensure your review is at least 50 characters.');
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      console.log('Review submitted:', formData);
      
      // Show success state
      setShowSuccess(true);
      
      // After showing success, navigate back to feed
      setTimeout(() => {
        if (onReviewSubmitted) {
          onReviewSubmitted();
        }
      }, 2000);
      
    } catch (error) {
      console.error('Error submitting review:', error);
      alert('Failed to submit review. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleMediaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      // Append new files to any existing
      setFormData(prev => ({
        ...prev,
        photos: [...prev.photos, ...files]
      }));
    }
  };

  const handleRemoveMedia = (idx: number) => {
    setFormData(prev => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== idx)
    }));
  };

  // Success state
  if (showSuccess) {
    return (
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <Card className="w-full bg-card border-border">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center space-y-4">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-foreground">Review Posted!</h2>
            <p className="text-muted-foreground max-w-md">
              Your concert review for <strong>{formData.artist}</strong> at <strong>{formData.venue}</strong> has been posted successfully.
            </p>
            <p className="text-sm text-muted-foreground">
              Redirecting to your feed...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const renderPreview = () => (
    <Card className="w-full bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-primary">
          <Music className="h-5 w-5" />
          Review Preview
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold">{formData.artist}</h3>
          <p className="text-muted-foreground">{formData.venue} • {formData.date}</p>
        </div>

        <div className="flex items-center gap-2">
          <StarRating rating={formData.ratings.overall} onRatingChange={() => {}} />
          <span className="text-sm text-muted-foreground">
            {formData.ratings.overall}/5 stars
          </span>
        </div>

        <div className="space-y-2">
          <h4 className="font-medium">Detailed Ratings</h4>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex justify-between">
              <span>Sound Quality:</span>
              <StarRating rating={formData.ratings.soundQuality} onRatingChange={() => {}} size="sm" />
            </div>
            <div className="flex justify-between">
              <span>Performance:</span>
              <StarRating rating={formData.ratings.performance} onRatingChange={() => {}} size="sm" />
            </div>
            <div className="flex justify-between">
              <span>Value:</span>
              <StarRating rating={formData.ratings.valueForMoney} onRatingChange={() => {}} size="sm" />
            </div>
          </div>
        </div>

        {formData.tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {formData.tags.map(tag => (
              <Badge key={tag} variant="secondary">{tag}</Badge>
            ))}
          </div>
        )}

        <div>
          <p className="text-sm leading-relaxed">{formData.reviewText}</p>
        </div>

        {formData.photos.length > 0 && (
          <div className="flex flex-wrap gap-4 mt-4">
            {formData.photos.map((file, idx) => {
              const url = URL.createObjectURL(file);
              if (file.type.startsWith('image/')) {
                return (
                  <img key={idx} src={url} alt={`photo-${idx}`} className="h-24 w-24 rounded-lg object-cover border" />
                );
              }
              if (file.type.startsWith('video/')) {
                return (
                  <video key={idx} controls src={url} className="h-24 w-32 rounded-lg border bg-black" />
                );
              }
              return null;
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (isPreviewMode) {
    return (
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        {renderPreview()}
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={() => setIsPreviewMode(false)}>
            <X className="h-4 w-4 mr-2" />
            Edit Review
          </Button>
          <Button 
            onClick={handleSubmit} 
            className="bg-primary hover:bg-primary/90"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Posting...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Post Review
              </>
            )}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card className="w-full bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <Music className="h-6 w-6" />
            Write a Concert Review
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Concert Search */}
          <div className="space-y-3 relative">
            <Label htmlFor="search" className="text-primary">Search Concert or Artist</Label>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="search"
                placeholder="Search for concerts, artists, or venues..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 text-primary placeholder:text-muted-foreground"
              />
            </div>
            
            {showSearch && (
              <Card className="absolute z-10 w-full bg-popover border-border shadow-lg">
                <CardContent className="p-3">
                  {searchResults.concerts.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground">Concerts</h4>
                      {searchResults.concerts.map(concert => (
                        <div
                          key={concert.id}
                          className="p-2 hover:bg-accent rounded cursor-pointer"
                          onClick={() => handleConcertSelect(concert)}
                        >
                          <div className="font-medium text-primary">{concert.artist}</div>
                          <div className="text-sm text-muted-foreground">
                            {concert.venue} • {concert.date}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {searchResults.venues.length > 0 && (
                    <div className="space-y-2 mt-4">
                      <h4 className="text-sm font-medium text-muted-foreground">Venues</h4>
                      {searchResults.venues.map(venue => (
                        <div
                          key={venue.id}
                          className="p-2 hover:bg-accent rounded cursor-pointer"
                          onClick={() => handleVenueSelect(venue)}
                        >
                          <div className="font-medium text-primary">{venue.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {venue.location} • Capacity: {venue.capacity}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Concert Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="artist" className="text-primary">Artist/Band *</Label>
              <Input
                id="artist"
                placeholder="Artist name"
                value={formData.artist}
                onChange={(e) => updateFormData('artist', e.target.value)}
                className="text-primary placeholder:text-muted-foreground"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="venue" className="text-primary">Venue *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="venue"
                  placeholder="Venue name"
                  value={formData.venue}
                  onChange={(e) => updateFormData('venue', e.target.value)}
                  className="pl-10 text-primary placeholder:text-muted-foreground"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="date" className="text-primary">Date *</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => updateFormData('date', e.target.value)}
                  className="pl-10 text-primary placeholder:text-muted-foreground"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Concert Ratings */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Concert Ratings</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Overall Rating *</Label>
                  <StarRating
                    rating={formData.ratings.overall}
                    onRatingChange={(rating) => updateRating('overall', rating)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label className="flex items-center gap-2">
                    <VolumeX className="h-4 w-4" />
                    Sound Quality
                  </Label>
                  <StarRating
                    rating={formData.ratings.soundQuality}
                    onRatingChange={(rating) => updateRating('soundQuality', rating)}
                  />
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="flex items-center gap-2">
                    <Heart className="h-4 w-4" />
                    Performance
                  </Label>
                  <StarRating
                    rating={formData.ratings.performance}
                    onRatingChange={(rating) => updateRating('performance', rating)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label>Value for Money</Label>
                  <StarRating
                    rating={formData.ratings.valueForMoney}
                    onRatingChange={(rating) => updateRating('valueForMoney', rating)}
                  />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Venue Rating Toggle */}
          <div className="flex items-center justify-between p-4 bg-secondary/10 rounded-lg">
            <div className="space-y-1">
              <Label className="text-base font-medium">Include Venue Rating</Label>
              <p className="text-sm text-muted-foreground">
                Add detailed ratings for the venue facilities and experience
              </p>
            </div>
            <Switch
              checked={includeVenueRating}
              onCheckedChange={handleToggleVenueRating}
            />
          </div>

          {/* Venue Ratings */}
          {includeVenueRating && formData.venueRatings && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Venue Ratings</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <VolumeX className="h-4 w-4" />
                      Sound Quality
                    </Label>
                    <StarRating
                      rating={formData.venueRatings.soundQuality}
                      onRatingChange={(rating) => updateVenueRating('soundQuality', rating)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Sight Lines
                    </Label>
                    <StarRating
                      rating={formData.venueRatings.sightLines}
                      onRatingChange={(rating) => updateVenueRating('sightLines', rating)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Accessibility
                    </Label>
                    <StarRating
                      rating={formData.venueRatings.accessibility}
                      onRatingChange={(rating) => updateVenueRating('accessibility', rating)}
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Coffee className="h-4 w-4" />
                      Amenities
                    </Label>
                    <StarRating
                      rating={formData.venueRatings.amenities}
                      onRatingChange={(rating) => updateVenueRating('amenities', rating)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Heart className="h-4 w-4" />
                      Staff Friendliness
                    </Label>
                    <StarRating
                      rating={formData.venueRatings.staffFriendliness}
                      onRatingChange={(rating) => updateVenueRating('staffFriendliness', rating)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="flex items-center gap-2">
                      <Car className="h-4 w-4" />
                      Location/Parking
                    </Label>
                    <StarRating
                      rating={formData.venueRatings.locationParking}
                      onRatingChange={(rating) => updateVenueRating('locationParking', rating)}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          <Separator />

          {/* Review Text */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="review" className="text-primary">Review Text *</Label>
              <span className={`text-sm ${
                characterCount < 50 ? 'text-destructive' : 
                characterCount > 1000 ? 'text-warning' : 
                'text-muted-foreground'
              }`}>
                {characterCount}/1000 characters {characterCount < 50 && '(min: 50)'}
              </span>
            </div>
            <Textarea
              id="review"
              placeholder="Share your experience... What made this concert special? How was the performance, venue, and overall experience?"
              value={formData.reviewText}
              onChange={(e) => updateFormData('reviewText', e.target.value)}
              className="min-h-32 text-primary placeholder:text-muted-foreground"
              maxLength={1000}
            />
          </div>

          {/* Media Upload */}
          <div className="space-y-3">
            <Label className="text-primary">Photos & Videos</Label>
            <div className="flex flex-wrap gap-4 mb-2">
              {formData.photos.length > 0 && formData.photos.map((file, idx) => {
                const url = URL.createObjectURL(file);
                return (
                  <div key={idx} className="relative group flex flex-col items-center">
                    {file.type.startsWith('image/') && (
                      <img src={url} alt={`media-${idx}`} className="h-20 w-20 rounded object-cover border" />
                    )}
                    {file.type.startsWith('video/') && (
                      <video src={url} className="h-20 w-20 rounded border bg-black" />
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemoveMedia(idx)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-6 w-6 flex items-center justify-center shadow hover:bg-red-700 scale-90 group-hover:scale-100 transition-all"
                      title="Remove"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                );
              })}
            </div>
            <Input
              type="file"
              accept="image/*,video/*"
              multiple
              onChange={handleMediaChange}
            />
            <span className="block text-xs text-muted-foreground mt-1">Supported formats: JPG, PNG, GIF, MP4, MOV. Up to 5 files.</span>
          </div>

          {/* Tags */}
          <div className="space-y-4">
            <TagSelector
              selectedTags={selectedTags.filter(tag => GENRE_TAGS.includes(tag))}
              availableTags={GENRE_TAGS}
              onTagToggle={handleTagToggle}
              title="Music Genres"
            />
            
            <TagSelector
              selectedTags={selectedTags.filter(tag => MOOD_TAGS.includes(tag))}
              availableTags={MOOD_TAGS}
              onTagToggle={handleTagToggle}
              title="Concert Mood"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 justify-end pt-6">
            <Button 
              variant="outline" 
              onClick={() => setIsPreviewMode(true)}
              disabled={!validateForm()}
            >
              <Eye className="h-4 w-4 mr-2" />
              Preview
            </Button>
            <Button 
              onClick={handleSubmit}
              disabled={!validateForm() || isSubmitting}
              className="bg-primary hover:bg-primary/90"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Posting...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Post Review
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};