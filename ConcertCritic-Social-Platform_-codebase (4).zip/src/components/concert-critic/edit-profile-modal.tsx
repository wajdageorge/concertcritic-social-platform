"use client";

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { AvatarUpload } from '@/components/ui/avatar-upload';
import { Check, AlertCircle, Loader2, User } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import supabase from '@/lib/supabase';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProfileUpdated: () => void;
}

interface ProfileFormData {
  username: string;
  bio: string;
  location: string;
  avatar_url: string;
}

interface FormErrors {
  username?: string;
  bio?: string;
  location?: string;
  avatar?: string;
  general?: string;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  onProfileUpdated
}) => {
  const { user, profile, refreshProfile } = useAuth();
  const [formData, setFormData] = useState<ProfileFormData>({
    username: '',
    bio: '',
    location: '',
    avatar_url: ''
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isUsernameChecking, setIsUsernameChecking] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  // Initialize form data when modal opens or profile changes
  useEffect(() => {
    if (isOpen) {
      if (profile) {
        setFormData({
          username: profile.username || '',
          bio: profile.bio || '',
          location: profile.location || '',
          avatar_url: profile.avatar_url || ''
        });
      } else {
        // For new profile creation
        setFormData({
          username: '',
          bio: '',
          location: '',
          avatar_url: ''
        });
      }
    }
  }, [isOpen, profile]);

  // Reset modal state when closed
  useEffect(() => {
    if (!isOpen) {
      setSelectedFile(null);
      setPreviewUrl('');
      setErrors({});
      setShowSuccess(false);
      setIsLoading(false);
      setIsUploading(false);
      setUploadProgress(0);
    }
  }, [isOpen]);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    // Username validation (optional but has constraints if provided)
    if (formData.username.trim()) {
      if (formData.username.length < 3) {
        newErrors.username = 'Username must be at least 3 characters';
      } else if (!/^[a-zA-Z0-9_]+$/.test(formData.username)) {
        newErrors.username = 'Username can only contain letters, numbers, and underscores';
      }
    }

    if (formData.bio.length > 500) {
      newErrors.bio = 'Bio must be 500 characters or less';
    }

    if (selectedFile) {
      if (selectedFile.size > 5 * 1024 * 1024) {
        newErrors.avatar = 'Image must be less than 5MB';
      }
      if (!selectedFile.type.startsWith('image/')) {
        newErrors.avatar = 'File must be an image';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const checkUsernameAvailability = async (username: string): Promise<boolean> => {
    if (!username.trim() || username === profile?.username) {
      return true;
    }

    setIsUsernameChecking(true);
    try {
      const usernameToCheck = username.trim().toLowerCase();
      console.log('Checking username availability for:', usernameToCheck);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', usernameToCheck)
        .neq('user_id', user?.id);

      console.log('Username check response:', { data, error });

      if (error) {
        console.error('Error checking username:', error);
        throw error;
      }
      
      // If we get any results, the username is taken
      const isAvailable = !data || data.length === 0;
      console.log('Username available:', isAvailable);
      
      return isAvailable;
    } catch (error) {
      console.error('Error checking username:', error);
      return false;
    } finally {
      setIsUsernameChecking(false);
    }
  };

  const handleInputChange = (field: keyof ProfileFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear specific field error
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const handleUsernameBlur = async () => {
    if (formData.username && formData.username !== profile?.username) {
      const isAvailable = await checkUsernameAvailability(formData.username);
      if (!isAvailable) {
        setErrors(prev => ({ ...prev, username: 'Username is already taken' }));
      }
    }
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    // Create preview URL
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    const preview = URL.createObjectURL(file);
    setPreviewUrl(preview);
    setErrors(prev => ({ ...prev, avatar: undefined }));
  };

  const uploadImage = async (file: File): Promise<string> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${user?.id}-${Date.now()}.${fileExt}`;
    const filePath = `${user?.id}/${fileName}`;

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev < 90) return prev + 10;
          return prev;
        });
      }, 100);

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, {
          upsert: true,
          cacheControl: '3600'
        });

      clearInterval(progressInterval);
      setUploadProgress(100);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      return publicUrl;
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    // Check username availability one more time (only if username provided)
    if (formData.username.trim() && formData.username !== profile?.username) {
      const isAvailable = await checkUsernameAvailability(formData.username);
      if (!isAvailable) {
        setErrors({ username: 'Username is already taken' });
        return;
      }
    }

    setIsLoading(true);
    setErrors({});

    try {
      let avatarUrl = formData.avatar_url;

      // Upload new image if selected
      if (selectedFile) {
        avatarUrl = await uploadImage(selectedFile);
      }

      const usernameToSave = formData.username.trim() ? formData.username.trim().toLowerCase() : null;
      console.log('Saving profile with username:', usernameToSave);

      // Update or create profile in database
      if (profile) {
        // Update existing profile
        const { error } = await supabase
          .from('profiles')
          .update({
            username: usernameToSave,
            bio: formData.bio.trim() || null,
            location: formData.location.trim() || null,
            avatar_url: avatarUrl || null,
            updated_at: new Date().toISOString()
          })
          .eq('user_id', user?.id);

        if (error) throw error;
      } else {
        // Create new profile
        const { error } = await supabase
          .from('profiles')
          .insert({
            user_id: user?.id,
            username: usernameToSave,
            bio: formData.bio.trim() || null,
            location: formData.location.trim() || null,
            avatar_url: avatarUrl || null,
          });

        if (error) throw error;
      }

      console.log('Profile saved successfully');

      // Show success state
      setShowSuccess(true);
      
      // Refresh profile data
      await refreshProfile();
      
      // Call success callback
      onProfileUpdated();

      // Close modal after short delay
      setTimeout(() => {
        onClose();
      }, 1500);

    } catch (error: any) {
      console.error('Error saving profile:', error);
      setErrors({ 
        general: error.message || 'Failed to save profile. Please try again.' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveAvatar = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl('');
    }
    setFormData(prev => ({ ...prev, avatar_url: '' }));
  };

  const currentAvatarUrl = previewUrl || formData.avatar_url;
  const bioCharCount = formData.bio.length;
  const bioCharLimit = 500;

  if (showSuccess) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="rounded-full bg-green-500/10 p-3 mb-4">
              <Check className="h-8 w-8 text-green-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">
              {profile ? 'Profile Updated!' : 'Profile Created!'}
            </h3>
            <p className="text-sm text-muted-foreground text-center">
              Your profile has been successfully {profile ? 'updated' : 'created'}.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            {profile ? 'Edit Profile' : 'Create Profile'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Avatar Section */}
          <div className="space-y-4">
            <Label>Profile Picture</Label>
            <AvatarUpload
              currentAvatar={currentAvatarUrl}
              onFileSelect={handleFileSelect}
              onRemove={handleRemoveAvatar}
              isUploading={isUploading}
              error={errors.avatar}
              disabled={isLoading}
            />
            
            {/* URL Input Fallback */}
            <div className="space-y-2">
              <Label htmlFor="avatar_url" className="text-sm text-muted-foreground">
                Or paste image URL
              </Label>
              <Input
                id="avatar_url"
                type="url"
                placeholder="https://example.com/image.jpg"
                value={formData.avatar_url}
                onChange={(e) => handleInputChange('avatar_url', e.target.value)}
                disabled={isLoading || isUploading}
              />
            </div>
          </div>

          {/* Username Field */}
          <div className="space-y-2">
            <Label htmlFor="username">Username (Optional)</Label>
            <div className="relative">
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => handleInputChange('username', e.target.value)}
                onBlur={handleUsernameBlur}
                placeholder="Choose a username (you can skip this)"
                className={errors.username ? 'border-destructive' : ''}
              />
              {isUsernameChecking && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Optional - You can set or change this anytime
            </p>
            {errors.username && (
              <p className="text-sm text-destructive flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                {errors.username}
              </p>
            )}
          </div>

          {/* Bio Field */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label htmlFor="bio">Bio</Label>
              <span className={`text-xs ${
                bioCharCount > bioCharLimit ? 'text-destructive' : 'text-muted-foreground'
              }`}>
                {bioCharCount}/{bioCharLimit}
              </span>
            </div>
            <Textarea
              id="bio"
              value={formData.bio}
              onChange={(e) => handleInputChange('bio', e.target.value)}
              placeholder="Tell us about yourself..."
              className={`resize-none ${errors.bio ? 'border-destructive' : ''}`}
              rows={4}
              maxLength={500}
            />
            {errors.bio && (
              <p className="text-sm text-destructive flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                {errors.bio}
              </p>
            )}
          </div>

          {/* Location Field */}
          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => handleInputChange('location', e.target.value)}
              placeholder="City, Country"
            />
          </div>

          {/* General Error */}
          {errors.general && (
            <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-3">
              <p className="text-sm text-destructive flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                {errors.general}
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading || isUploading}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading || isUploading || isUsernameChecking || Object.keys(errors).length > 0}
              className="flex-1"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  {profile ? 'Saving...' : 'Creating...'}
                </div>
              ) : (
                profile ? 'Save Changes' : 'Create Profile'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};