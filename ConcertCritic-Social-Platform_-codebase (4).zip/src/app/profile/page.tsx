"use client";

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { ProfileAnalytics } from '@/components/concert-critic/profile-analytics';
import { EditProfileModal } from '@/components/concert-critic/edit-profile-modal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Plus, LogIn, ArrowLeft } from 'lucide-react';

export default function ProfilePage() {
  const { user, profile, loading } = useAuth();
  const [showEditModal, setShowEditModal] = useState(false);
  const router = useRouter();

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  // Not authenticated
  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <LogIn className="w-8 h-8 text-primary" />
            </div>
            <CardTitle>Sign In Required</CardTitle>
            <CardDescription>
              You need to be logged in to view your profile.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link href="/auth/login" className="block">
              <Button className="w-full">
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </Button>
            </Link>
            <Link href="/" className="block">
              <Button variant="outline" className="w-full">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Authenticated but no profile
  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-primary" />
            </div>
            <CardTitle>Welcome to Concert Critic!</CardTitle>
            <CardDescription>
              Complete your profile to get started and unlock all features.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={() => setShowEditModal(true)}
              className="w-full"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Profile
            </Button>
            <Button 
              variant="outline" 
              onClick={() => router.push('/app')}
              className="w-full"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to App
            </Button>
          </CardContent>
        </Card>

        <EditProfileModal 
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          onProfileUpdated={() => {
            setShowEditModal(false);
            // Profile will be refreshed automatically via auth context
          }}
        />
      </div>
    );
  }

  // Authenticated with profile - show analytics
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.push('/app')}
                className="mr-2"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to App
              </Button>
              <div>
                <h1 className="text-3xl font-bold">Your Profile</h1>
                <p className="text-muted-foreground">
                  Welcome back, {profile.username}
                </p>
              </div>
            </div>
            <Button 
              variant="outline"
              onClick={() => setShowEditModal(true)}
            >
              <User className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          </div>

          <ProfileAnalytics />

          <EditProfileModal 
            isOpen={showEditModal}
            onClose={() => setShowEditModal(false)}
            onProfileUpdated={() => {
              setShowEditModal(false);
              // Profile will be refreshed automatically via auth context
            }}
          />
        </div>
      </div>
    </div>
  );
}