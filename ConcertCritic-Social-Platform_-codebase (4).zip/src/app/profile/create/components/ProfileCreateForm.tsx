"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { AlertCircle, CheckCircle2, Loader2, User } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import supabase from '@/lib/supabase';

interface FormData {
  username: string;
  bio: string;
  location: string;
  avatarUrl: string;
}

interface FormErrors {
  username?: string;
  bio?: string;
  location?: string;
  avatarUrl?: string;
  general?: string;
}

export const ProfileCreateForm = () => {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [formData, setFormData] = useState<FormData>({
    username: '',
    bio: '',
    location: '',
    avatarUrl: ''
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      router.push('/auth/login');
    }
  }, [user, loading, router]);

  const validateForm = (): FormErrors => {
    const newErrors: FormErrors = {};

    // Username validation (optional but has constraints if provided)
    if (formData.username.trim()) {
      if (formData.username.length < 3) {
        newErrors.username = 'Username must be at least 3 characters';
      } else if (formData.username.length > 20) {
        newErrors.username = 'Username must be less than 20 characters';
      } else if (!/^[a-zA-Z0-9_]+$/.test(formData.username)) {
        newErrors.username = 'Username can only contain letters, numbers, and underscores';
      }
    }

    // Bio validation (optional but has length limit)
    if (formData.bio.length > 500) {
      newErrors.bio = 'Bio must be less than 500 characters';
    }

    // Location validation (optional but has length limit)
    if (formData.location.length > 100) {
      newErrors.location = 'Location must be less than 100 characters';
    }

    // Avatar URL validation (optional but should be valid URL if provided)
    if (formData.avatarUrl && formData.avatarUrl.trim()) {
      try {
        new URL(formData.avatarUrl);
      } catch {
        newErrors.avatarUrl = 'Please enter a valid URL';
      }
    }

    return newErrors;
  };

  const handleChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear specific field error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
    
    // Clear general error
    if (errors.general) {
      setErrors(prev => ({ ...prev, general: undefined }));
    }
    
    // Clear success state
    if (isSuccess) {
      setIsSuccess(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user?.email) {
      setErrors({ general: 'You must be logged in to create a profile.' });
      return;
    }

    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      // Check if username is already taken (only if username provided)
      if (formData.username.trim()) {
        const usernameToCheck = formData.username.trim().toLowerCase();
        console.log('Checking username availability for:', usernameToCheck);
        
        const { data: existingProfiles, error: checkError } = await supabase
          .from('profiles')
          .select('username')
          .eq('username', usernameToCheck);

        console.log('Username check response:', { data: existingProfiles, error: checkError });

        if (checkError) {
          console.error('Error checking username:', checkError);
          throw new Error('Error checking username availability');
        }

        // If we get any results, the username is taken
        if (existingProfiles && existingProfiles.length > 0) {
          console.log('Username taken, found profiles:', existingProfiles);
          setErrors({ username: 'Username already exists. Please choose a different username.' });
          return;
        }

        console.log('Username available, proceeding with profile creation');
      }

      // Check if user already has a profile
      const { data: userProfile, error: userCheckError } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', user.email)
        .single();

      if (userCheckError && userCheckError.code !== 'PGRST116') {
        console.error('Error checking existing profile:', userCheckError);
        throw new Error('Error checking existing profile');
      }

      if (userProfile) {
        setErrors({ general: 'You already have a profile.' });
        return;
      }

      // Create the profile using the new simplified schema
      const { data, error } = await supabase
        .from('profiles')
        .insert([
          {
            email: user.email,
            username: formData.username.trim() ? formData.username.trim().toLowerCase() : null,
            bio: formData.bio.trim() || null,
            location: formData.location.trim() || null,
            avatar_url: formData.avatarUrl.trim() || null,
          },
        ])
        .select()
        .single();

      if (error) {
        console.error('Error creating profile:', error);
        throw new Error(error.message);
      }

      console.log('Profile created successfully:', data);

      // Success: clear form and show success message
      setFormData({
        username: '',
        bio: '',
        location: '',
        avatarUrl: ''
      });
      setIsSuccess(true);
      
      // Redirect to dashboard after a brief delay
      setTimeout(() => {
        router.push('/dashboard');
      }, 2000);
    } catch (error) {
      console.error('Profile creation error:', error);
      setErrors({
        general: error instanceof Error ? error.message : 'An unexpected error occurred'
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="w-full max-w-2xl mx-auto p-4">
        <div className="text-center">
          <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to login
  }

  return (
    <div className="w-full max-w-2xl mx-auto p-4">
      <Card className="bg-card border-border">
        <CardHeader className="space-y-2">
          <div className="flex items-center gap-2">
            <User className="h-5 w-5 text-primary" />
            <CardTitle className="text-h2">Create Your Profile</CardTitle>
          </div>
          <CardDescription className="text-muted-foreground">
            Set up your profile to get started. Logged in as: {user.email}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Success Message */}
          {isSuccess && (
            <div 
              className="flex items-center gap-2 p-4 bg-green-900/20 border border-green-700 rounded-md text-green-400"
              role="alert"
              aria-live="polite"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Profile created successfully! Redirecting to dashboard...</span>
            </div>
          )}

          {/* General Error */}
          {errors.general && (
            <div 
              className="flex items-center gap-2 p-4 bg-destructive/10 border border-destructive rounded-md text-destructive"
              role="alert"
              aria-live="polite"
            >
              <AlertCircle className="h-4 w-4" />
              <span>{errors.general}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            {/* Username Field */}
            <div className="space-y-2">
              <Label htmlFor="username" className="text-foreground font-medium">
                Username (Optional)
              </Label>
              <Input
                id="username"
                type="text"
                value={formData.username}
                onChange={(e) => handleChange('username', e.target.value)}
                placeholder="Choose a username (you can set this later)"
                className={`bg-input border-border focus:ring-ring ${
                  errors.username ? 'border-destructive focus:ring-destructive' : ''
                }`}
                aria-invalid={errors.username ? 'true' : 'false'}
                aria-describedby={errors.username ? 'username-error username-hint' : 'username-hint'}
                disabled={isLoading}
                autoComplete="username"
              />
              <p id="username-hint" className="text-sm text-muted-foreground">
                Optional - You can skip this and set your username later
              </p>
              {errors.username && (
                <p 
                  id="username-error" 
                  className="text-sm text-destructive flex items-center gap-1"
                  role="alert"
                >
                  <AlertCircle className="h-3 w-3" />
                  {errors.username}
                </p>
              )}
            </div>

            {/* Bio Field */}
            <div className="space-y-2">
              <Label htmlFor="bio" className="text-foreground font-medium">
                Bio (Optional)
              </Label>
              <Textarea
                id="bio"
                value={formData.bio}
                onChange={(e) => handleChange('bio', e.target.value)}
                placeholder="Tell us a bit about yourself..."
                className={`bg-input border-border focus:ring-ring min-h-[100px] resize-y ${
                  errors.bio ? 'border-destructive focus:ring-destructive' : ''
                }`}
                aria-invalid={errors.bio ? 'true' : 'false'}
                aria-describedby={errors.bio ? 'bio-error bio-hint' : 'bio-hint'}
                disabled={isLoading}
                maxLength={500}
              />
              <div className="text-sm text-muted-foreground flex justify-between">
                <span id="bio-hint">Optional - Share something about yourself</span>
                <span>{formData.bio.length}/500</span>
              </div>
              {errors.bio && (
                <p 
                  id="bio-error" 
                  className="text-sm text-destructive flex items-center gap-1"
                  role="alert"
                >
                  <AlertCircle className="h-3 w-3" />
                  {errors.bio}
                </p>
              )}
            </div>

            {/* Location Field */}
            <div className="space-y-2">
              <Label htmlFor="location" className="text-foreground font-medium">
                Location (Optional)
              </Label>
              <Input
                id="location"
                type="text"
                value={formData.location}
                onChange={(e) => handleChange('location', e.target.value)}
                placeholder="Where are you based?"
                className={`bg-input border-border focus:ring-ring ${
                  errors.location ? 'border-destructive focus:ring-destructive' : ''
                }`}
                aria-invalid={errors.location ? 'true' : 'false'}
                aria-describedby={errors.location ? 'location-error location-hint' : 'location-hint'}
                disabled={isLoading}
                maxLength={100}
              />
              <p id="location-hint" className="text-sm text-muted-foreground">
                Optional - Your city or general location
              </p>
              {errors.location && (
                <p 
                  id="location-error" 
                  className="text-sm text-destructive flex items-center gap-1"
                  role="alert"
                >
                  <AlertCircle className="h-3 w-3" />
                  {errors.location}
                </p>
              )}
            </div>

            {/* Avatar URL Field */}
            <div className="space-y-2">
              <Label htmlFor="avatarUrl" className="text-foreground font-medium">
                Avatar URL (Optional)
              </Label>
              <Input
                id="avatarUrl"
                type="url"
                value={formData.avatarUrl}
                onChange={(e) => handleChange('avatarUrl', e.target.value)}
                placeholder="https://example.com/your-avatar.jpg"
                className={`bg-input border-border focus:ring-ring ${
                  errors.avatarUrl ? 'border-destructive focus:ring-destructive' : ''
                }`}
                aria-invalid={errors.avatarUrl ? 'true' : 'false'}
                aria-describedby={errors.avatarUrl ? 'avatar-error avatar-hint' : 'avatar-hint'}
                disabled={isLoading}
              />
              <p id="avatar-hint" className="text-sm text-muted-foreground">
                Optional - Link to your profile picture
              </p>
              {errors.avatarUrl && (
                <p 
                  id="avatar-error" 
                  className="text-sm text-destructive flex items-center gap-1"
                  role="alert"
                >
                  <AlertCircle className="h-3 w-3" />
                  {errors.avatarUrl}
                </p>
              )}
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <Button 
                type="submit" 
                disabled={isLoading}
                className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground font-medium px-8"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Creating Profile...
                  </>
                ) : (
                  'Create Profile'
                )}
              </Button>
            </div>
          </form>

          <div className="text-sm text-muted-foreground pt-2">
            All fields are optional - you can complete your profile anytime!
          </div>
        </CardContent>
      </Card>
    </div>
  );
};