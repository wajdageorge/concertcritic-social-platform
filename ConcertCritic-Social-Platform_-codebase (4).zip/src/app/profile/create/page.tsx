import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ProfileCreateForm } from "./components/ProfileCreateForm";

export default function CreateProfilePage() {
  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-h1 mb-2">Create Profile</h1>
          <p className="text-caption">
            Set up your profile to get started. All fields are optional - you can complete your profile anytime!
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>
              Enter your profile details. All fields are optional and can be updated later.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ProfileCreateForm />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}