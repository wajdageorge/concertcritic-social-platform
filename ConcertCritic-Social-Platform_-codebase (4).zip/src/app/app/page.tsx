"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { BottomNavigation } from "@/components/concert-critic/bottom-navigation";
import { SocialFeed } from "@/components/concert-critic/social-feed";
import { ConcertDiscovery } from "@/components/concert-critic/concert-discovery";
import { ReviewComposer } from "@/components/concert-critic/review-composer";
import { ProfileAnalytics } from "@/components/concert-critic/profile-analytics";
import { SettingsPage } from "@/components/concert-critic/settings-page";
import { UserSearch } from "@/components/concert-critic/user-search";
import { EditProfileModal } from "@/components/concert-critic/edit-profile-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Plus } from "lucide-react";

type TabType = "home" | "search" | "add" | "discover" | "profile" | "settings";

export default function MainApp() {
  const { user, profile, loading, profileLoading } = useAuth();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabType>("home");
  const [showProfileModal, setShowProfileModal] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      router.push('/auth/login');
    }
  }, [user, loading, router]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab as TabType);
  };

  const handleNavigateToAddReview = () => {
    setActiveTab("add");
  };

  const handleProfileCreated = () => {
    setShowProfileModal(false);
    // Profile will be automatically refreshed via the auth context
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "home":
        return <SocialFeed onNavigateToAddReview={handleNavigateToAddReview} />;
      case "search":
        return <UserSearch />;
      case "add":
        return <ReviewComposer onReviewSubmitted={() => setActiveTab("home")} />;
      case "discover":
        return <ConcertDiscovery onNavigateToAddReview={handleNavigateToAddReview} />;
      case "profile":
        // If no profile exists, show create profile prompt
        if (!profile && !profileLoading) {
          return (
            <div className="min-h-screen bg-background flex items-center justify-center p-4">
              <Card className="w-full max-w-md">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="w-8 h-8 text-primary" />
                  </div>
                  <CardTitle>Create Your Profile</CardTitle>
                  <CardDescription>
                    Welcome to Concert Critic! Set up your profile to start reviewing concerts and connecting with other music lovers.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={() => setShowProfileModal(true)} 
                    className="w-full"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Profile
                  </Button>
                </CardContent>
              </Card>
            </div>
          );
        }
        return <ProfileAnalytics />;
      case "settings":
        return <SettingsPage />;
      default:
        return <SocialFeed onNavigateToAddReview={handleNavigateToAddReview} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect to login
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Main Content Area */}
      <main className="pb-24 min-h-screen overflow-x-hidden">
        {renderTabContent()}
      </main>

      {/* Fixed Bottom Navigation */}
      <BottomNavigation
        activeTab={activeTab}
        onTabChange={handleTabChange}
      />

      {/* Profile Creation Modal */}
      <EditProfileModal
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        onProfileUpdated={handleProfileCreated}
      />
    </div>
  );
}