import { NextRequest, NextResponse } from 'next/server'
import supabase from '@/lib/supabase'

interface CreateProfileRequest {
  username: string
  bio?: string
  avatarUrl?: string
}

interface UpdateProfileRequest {
  username?: string
  bio?: string
  location?: string
  avatar_url?: string
}

function validateCreateProfileRequest(body: any): body is CreateProfileRequest {
  if (!body || typeof body !== 'object') {
    return false
  }
  // Must have username
  if (!body.username || typeof body.username !== 'string' || body.username.trim().length === 0) {
    return false
  }
  // Optional fields
  if (body.bio !== undefined && typeof body.bio !== 'string') {
    return false
  }
  if (body.avatarUrl !== undefined && typeof body.avatarUrl !== 'string') {
    return false
  }
  return true
}

function validateUpdateProfileRequest(body: any): body is UpdateProfileRequest {
  if (!body || typeof body !== 'object') {
    return false
  }
  
  // All fields are optional for updates
  if (body.username !== undefined && (typeof body.username !== 'string' || body.username.trim().length === 0)) {
    return false
  }
  if (body.bio !== undefined && typeof body.bio !== 'string') {
    return false
  }
  if (body.location !== undefined && typeof body.location !== 'string') {
    return false
  }
  if (body.avatar_url !== undefined && typeof body.avatar_url !== 'string') {
    return false
  }
  
  return true
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    // Note: For a production app, you'd want to verify the JWT token on the server
    // For now, we'll rely on client-side authentication
    const body = await request.json()
    if (!validateCreateProfileRequest(body)) {
      return NextResponse.json(
        { message: 'Invalid request body. Username is required.' },
        { status: 400 }
      )
    }

    const { username, bio, avatarUrl } = body

    // This is a simplified implementation
    // In a real app, you'd want to verify the user's authentication server-side
    return NextResponse.json({
      message: 'Profile API ready. Client-side profile creation recommended with Supabase.',
    }, { status: 200 })
  } catch (error: any) {
    // JSON parse error
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { message: 'Invalid JSON in request body.' },
        { status: 400 }
      )
    }

    // Other generic
    console.error('Error in profile API:', error)
    return NextResponse.json(
      { message: 'Internal server error occurred.' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json()
    if (!validateUpdateProfileRequest(body)) {
      return NextResponse.json(
        { message: 'Invalid request body.' },
        { status: 400 }
      )
    }

    // This is a simplified implementation
    // In a real app, you'd want to verify the user's authentication server-side
    // and handle the actual profile update logic here
    return NextResponse.json({
      message: 'Profile update API ready. Client-side profile updates recommended with Supabase.',
      data: body
    }, { status: 200 })
  } catch (error: any) {
    // JSON parse error
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { message: 'Invalid JSON in request body.' },
        { status: 400 }
      )
    }

    // Other generic
    console.error('Error in profile update API:', error)
    return NextResponse.json(
      { message: 'Internal server error occurred.' },
      { status: 500 }
    )
  }
}