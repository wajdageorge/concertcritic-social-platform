import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  console.log('Events API called');

  try {
    // Validate environment variables
    const apiKey = process.env.TICKETMASTER_API_KEY;
    if (!apiKey) {
      console.error('TICKETMASTER_API_KEY is not configured');
      return NextResponse.json(
        { error: 'Service configuration error - API key missing' },
        { status: 500 }
      );
    }

    // Parse query parameters
    const url = new URL(request.url);
    const keyword = url.searchParams.get('keyword') || '';
    const location = url.searchParams.get('location') || '';
    const genre = url.searchParams.get('genre') || '';
    const page = parseInt(url.searchParams.get('page') || '0');
    const limit = parseInt(url.searchParams.get('limit') || '20');

    console.log('Search params:', { keyword, location, genre, page, limit });

    // Build Ticketmaster API URL
    const ticketmasterUrl = new URL('https://app.ticketmaster.com/discovery/v2/events.json');
    ticketmasterUrl.searchParams.set('apikey', apiKey);
    ticketmasterUrl.searchParams.set('size', Math.min(limit, 200).toString());
    ticketmasterUrl.searchParams.set('page', page.toString());
    ticketmasterUrl.searchParams.set('segmentName', 'Music'); // Only music events

    if (keyword) {
      ticketmasterUrl.searchParams.set('keyword', keyword);
    }

    if (location && location !== 'all') {
      ticketmasterUrl.searchParams.set('city', location);
    }

    if (genre && genre !== 'all') {
      ticketmasterUrl.searchParams.set('classificationName', genre);
    }

    console.log('Calling Ticketmaster API:', ticketmasterUrl.toString().replace(/apikey=[^&]*/, 'apikey=***'));

    // Make API request with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

    try {
      const response = await fetch(ticketmasterUrl.toString(), {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'ConcertCritic/1.0'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      console.log('Ticketmaster response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Ticketmaster API error:', response.status, errorText.substring(0, 500));
        
        return NextResponse.json(
          { 
            error: `Ticketmaster API error: ${response.status}`,
            details: response.statusText,
            debug: errorText.substring(0, 200)
          },
          { status: 502 }
        );
      }

      const data = await response.json();
      console.log('Ticketmaster data received:', {
        hasEvents: !!(data._embedded?.events),
        eventCount: data._embedded?.events?.length || 0,
        pageInfo: data.page
      });

      // Transform events to our format
      const events = data._embedded?.events || [];
      const concerts = events.map((event: any) => {
        const venue = event._embedded?.venues?.[0];
        const attraction = event._embedded?.attractions?.[0];
        
        // Get the best quality image
        const image = event.images
          ?.filter((img: any) => img.ratio === '16_9')
          ?.sort((a: any, b: any) => b.width - a.width)?.[0]?.url ||
          event.images?.[0]?.url;

        return {
          id: event.id,
          title: event.name,
          artist: attraction?.name || 'Various Artists',
          venue: venue?.name || 'TBA',
          location: venue ? `${venue.city.name}, ${venue.state?.stateCode || venue.country?.countryCode}` : 'TBA',
          date: event.dates.start.localDate,
          time: event.dates.start.localTime,
          price: event.priceRanges?.[0] ? {
            min: event.priceRanges[0].min,
            max: event.priceRanges[0].max,
            currency: event.priceRanges[0].currency
          } : undefined,
          image,
          ticketUrl: event.url,
          status: event.dates.status.code === 'onsale' ? 'on_sale' as const : 
                 event.dates.status.code === 'soldout' ? 'sold_out' as const :
                 event.dates.status.code === 'cancelled' ? 'cancelled' as const :
                 'on_sale' as const,
          coordinates: venue?.location ? {
            lat: parseFloat(venue.location.latitude),
            lng: parseFloat(venue.location.longitude)
          } : undefined,
          genres: event.classifications?.[0] ? [
            event.classifications[0].genre?.name,
            event.classifications[0].subGenre?.name
          ].filter(Boolean) : undefined
        };
      });

      console.log('Transformed concerts:', concerts.length);

      // Prepare response
      const response_data = {
        data: concerts,
        pagination: {
          page: data.page?.number || 0,
          limit: data.page?.size || limit,
          total: data.page?.totalElements || 0,
          totalPages: data.page?.totalPages || 0,
          hasNext: data._links?.next !== undefined,
          hasPrev: data._links?.prev !== undefined
        },
        meta: {
          query: { keyword, location, genre, page, limit },
          resultsCount: concerts.length,
          timestamp: new Date().toISOString()
        }
      };

      return NextResponse.json(response_data, {
        headers: {
          'Cache-Control': 'public, max-age=300, stale-while-revalidate=600',
        }
      });

    } catch (fetchError) {
      clearTimeout(timeoutId);
      
      if (fetchError instanceof Error && fetchError.name === 'AbortError') {
        console.error('Ticketmaster API request timeout');
        return NextResponse.json(
          { error: 'Request timeout - Ticketmaster API took too long to respond' },
          { status: 504 }
        );
      }

      console.error('Fetch error:', fetchError);
      return NextResponse.json(
        { 
          error: 'Network error connecting to Ticketmaster API',
          details: fetchError instanceof Error ? fetchError.message : 'Unknown network error'
        },
        { status: 502 }
      );
    }

  } catch (error) {
    console.error('Events API error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

// Handle other HTTP methods
export async function POST() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}

export async function PUT() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}

export async function DELETE() {
  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}