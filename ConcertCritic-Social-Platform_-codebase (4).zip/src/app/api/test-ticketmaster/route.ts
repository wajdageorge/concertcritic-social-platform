import { NextResponse } from 'next/server';

export async function GET() {
  console.log('Testing Ticketmaster API connection...');

  try {
    // Check if API key is available
    const apiKey = process.env.TICKETMASTER_API_KEY;
    
    if (!apiKey) {
      console.error('TICKETMASTER_API_KEY environment variable is not set');
      return NextResponse.json(
        {
          success: false,
          error: 'TICKETMASTER_API_KEY environment variable is not configured',
          details: 'Please set the TICKETMASTER_API_KEY in your environment variables'
        },
        { status: 500 }
      );
    }

    console.log('API key found (first 10 chars):', apiKey.substring(0, 10) + '...');

    // Make a minimal test request to Ticketmaster Discovery API
    const testUrl = `https://app.ticketmaster.com/discovery/v2/events.json?apikey=${apiKey}&size=5&page=0&segmentName=Music`;
    
    console.log('Making request to Ticketmaster API...');

    const response = await fetch(testUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'ConcertCritic/1.0'
      },
    });

    console.log('Response status:', response.status);
    console.log('Response status text:', response.statusText);

    const responseText = await response.text();
    console.log('Response body length:', responseText.length);

    if (!response.ok) {
      console.error('Ticketmaster API error response:', responseText.substring(0, 1000));
      return NextResponse.json(
        {
          success: false,
          error: `Ticketmaster API returned ${response.status}: ${response.statusText}`,
          details: {
            status: response.status,
            statusText: response.statusText,
            apiKeyLength: apiKey.length,
            responsePreview: responseText.substring(0, 500)
          }
        },
        { status: 500 }
      );
    }

    let data;
    try {
      data = JSON.parse(responseText);
    } catch (parseError) {
      console.error('Failed to parse JSON response:', parseError);
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to parse JSON response from Ticketmaster API',
          details: {
            parseError: parseError instanceof Error ? parseError.message : 'Unknown parse error',
            responsePreview: responseText.substring(0, 500)
          }
        },
        { status: 500 }
      );
    }

    console.log('Successfully connected to Ticketmaster API');
    console.log('Data structure:', {
      hasPage: !!data.page,
      hasEmbedded: !!data._embedded,
      hasEvents: !!(data._embedded && data._embedded.events),
      eventCount: data._embedded && data._embedded.events ? data._embedded.events.length : 0
    });

    const sampleEvents = data._embedded?.events?.slice(0, 3).map((event: any) => ({
      id: event.id,
      name: event.name,
      date: event.dates?.start?.localDate,
      venue: event._embedded?.venues?.[0]?.name,
      city: event._embedded?.venues?.[0]?.city?.name,
      status: event.dates?.status?.code
    })) || [];

    return NextResponse.json({
      success: true,
      message: 'Successfully connected to Ticketmaster API',
      details: {
        apiKeyConfigured: true,
        apiKeyLength: apiKey.length,
        responseStatus: response.status,
        hasData: !!data,
        pageInfo: data.page || null,
        eventCount: data._embedded && data._embedded.events ? data._embedded.events.length : 0,
        sampleEvents
      }
    });

  } catch (error) {
    console.error('Error testing Ticketmaster API:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to connect to Ticketmaster API',
        details: {
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          errorType: error instanceof Error ? error.constructor.name : typeof error,
          stack: error instanceof Error ? error.stack?.split('\n').slice(0, 5) : null
        }
      },
      { status: 500 }
    );
  }
}