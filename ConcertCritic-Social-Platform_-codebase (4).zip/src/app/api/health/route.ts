import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy'
  timestamp: string
  database: {
    connected: boolean
    error?: string
  }
  system: {
    nodeVersion: string
    platform: string
    uptime: number
    memory: {
      used: number
      total: number
      percentage: number
    }
  }
  environment: string
}

export async function GET(request: NextRequest): Promise<NextResponse<HealthCheckResponse>> {
  const isDevelopment = process.env.NODE_ENV === 'development'
  const timestamp = new Date().toISOString()
  
  // Collect system information
  const memoryUsage = process.memoryUsage()
  const systemInfo = {
    nodeVersion: process.version,
    platform: process.platform,
    uptime: Math.round(process.uptime()),
    memory: {
      used: Math.round(memoryUsage.heapUsed / 1024 / 1024), // MB
      total: Math.round(memoryUsage.heapTotal / 1024 / 1024), // MB
      percentage: Math.round((memoryUsage.heapUsed / memoryUsage.heapTotal) * 100)
    }
  }

  let databaseStatus = {
    connected: false,
    error: undefined as string | undefined
  }

  let overallStatus: 'healthy' | 'unhealthy' = 'unhealthy'

  try {
    // Test Supabase connection
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      databaseStatus.connected = false
      databaseStatus.error = isDevelopment ? 'Supabase environment variables not configured' : 'Database configuration error'
    } else {
      const supabase = createClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
      )

      // Simple health check by trying to select from auth.users (this will always work if Supabase is up)
      const { error } = await supabase.from('profiles').select('count').limit(1).single()
      
      if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned" which is fine
        databaseStatus.connected = false
        databaseStatus.error = isDevelopment ? `Supabase connection failed: ${error.message}` : 'Database connection failed'
      } else {
        databaseStatus.connected = true
        overallStatus = 'healthy'
      }
    }
  } catch (error) {
    databaseStatus.connected = false
    databaseStatus.error = isDevelopment 
      ? `Health check failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      : 'Database health check failed'
  }

  const response: HealthCheckResponse = {
    status: overallStatus,
    timestamp,
    database: databaseStatus,
    system: systemInfo,
    environment: process.env.NODE_ENV || 'unknown'
  }

  const statusCode = overallStatus === 'healthy' ? 200 : 500

  return NextResponse.json(response, { 
    status: statusCode,
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    }
  })
}