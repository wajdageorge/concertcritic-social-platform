"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"

export default function LandingPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && user) {
      router.push('/app')
    }
  }, [user, loading, router])

  if (loading) {
    return (
      <div className="relative min-h-screen flex items-center justify-center px-4 bg-background overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-black z-0" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80 z-10 pointer-events-none" />
        <div className="relative z-20 text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (user) {
    return null // Will redirect to dashboard
  }

  return (
    <div className="relative min-h-screen flex items-center justify-center px-4 bg-background overflow-hidden">
      {/* Concert background with gradient fallback */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-black z-0" />
      
      {/* Dark overlay for better text contrast */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80 z-10 pointer-events-none" />

      {/* Content overlay */}
      <div className="relative z-20 flex flex-col items-center justify-center w-full max-w-xl text-center space-y-8 py-16">
        <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent drop-shadow-lg mb-2">
          ConcertCritic
        </h1>
        <p className="text-lg md:text-2xl text-muted-foreground mb-6 max-w-xl mx-auto font-medium drop-shadow-md">
          Discover, rate, and discuss live music experiences. Create your account to become a critic or log in to join the community.
        </p>
        <div className="flex flex-col items-center gap-4 mt-8 w-full md:flex-row md:justify-center">
          <Link href="/auth/signup" className="w-full md:w-48">
            <Button size="lg" className="w-full md:w-48 shadow-xl">Create Account</Button>
          </Link>
          <span className="text-gray-200 mx-0 md:mx-6">or</span>
          <Link href="/auth/login" className="w-full md:w-48">
            <Button variant="outline" size="lg" className="w-full md:w-48 shadow">Log In</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}