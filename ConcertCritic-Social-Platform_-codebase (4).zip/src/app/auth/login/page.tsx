import { Suspense } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { LoginForm } from "./login-form"

function LoginError({ searchParams }: { searchParams: { error?: string } }) {
  if (!searchParams.error) return null
  
  return (
    <div className="mb-4 p-3 rounded-md bg-destructive/15 border border-destructive/20">
      <p className="text-sm text-destructive">
        {searchParams.error === 'CredentialsSignin' 
          ? 'Invalid email or password' 
          : 'An error occurred during sign in'
        }
      </p>
    </div>
  )
}

export default function LoginPage({ searchParams }: { searchParams: { error?: string } }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-2 text-center">
          <CardTitle className="text-2xl font-bold">Sign In</CardTitle>
          <CardDescription>
            Enter your credentials to access your account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Suspense fallback={null}>
            <LoginError searchParams={searchParams} />
          </Suspense>
          <LoginForm />
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-sm text-muted-foreground text-center">
            Don't have an account?{" "}
            <Link 
              href="/auth/signup" 
              className="text-primary hover:underline font-medium"
            >
              Sign up
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}