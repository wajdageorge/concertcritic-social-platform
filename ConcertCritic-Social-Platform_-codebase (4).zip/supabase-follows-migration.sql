-- ConcertCritic Follow System Migration
-- This migration adds user following functionality with proper RLS, indexes, and triggers

-- ==========================================
-- CREATE FOLLOWS TABLE
-- ==========================================

-- Create the follows table for user following relationships
CREATE TABLE IF NOT EXISTS public.follows (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    follower_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    following_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    
    -- Unique constraint to prevent duplicate follow relationships
    CONSTRAINT unique_follow_relationship UNIQUE (follower_id, following_id),
    
    -- Check constraint to prevent users from following themselves
    CONSTRAINT no_self_follow CHECK (follower_id != following_id)
);

-- Add table comment
COMMENT ON TABLE public.follows IS 'Stores user following relationships for the social features of ConcertCritic';
COMMENT ON COLUMN public.follows.id IS 'Unique identifier for the follow relationship';
COMMENT ON COLUMN public.follows.follower_id IS 'ID of the user who is following (the follower)';
COMMENT ON COLUMN public.follows.following_id IS 'ID of the user being followed (the followee)';
COMMENT ON COLUMN public.follows.created_at IS 'Timestamp when the follow relationship was created';

-- ==========================================
-- UPDATE PROFILES TABLE
-- ==========================================

-- Add follower and following count columns to profiles table
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS followers_count INTEGER DEFAULT 0 NOT NULL,
ADD COLUMN IF NOT EXISTS following_count INTEGER DEFAULT 0 NOT NULL;

-- Add comments for new columns
COMMENT ON COLUMN public.profiles.followers_count IS 'Cached count of users following this profile';
COMMENT ON COLUMN public.profiles.following_count IS 'Cached count of users this profile is following';

-- Add check constraints to ensure counts are never negative
ALTER TABLE public.profiles 
ADD CONSTRAINT followers_count_non_negative CHECK (followers_count >= 0),
ADD CONSTRAINT following_count_non_negative CHECK (following_count >= 0);

-- ==========================================
-- CREATE INDEXES FOR PERFORMANCE
-- ==========================================

-- Index on follower_id for finding who someone follows
CREATE INDEX IF NOT EXISTS idx_follows_follower_id ON public.follows(follower_id);

-- Index on following_id for finding who follows someone
CREATE INDEX IF NOT EXISTS idx_follows_following_id ON public.follows(following_id);

-- Composite index for relationship checks and ordered queries
CREATE INDEX IF NOT EXISTS idx_follows_composite ON public.follows(follower_id, following_id);

-- Index on created_at for chronological queries
CREATE INDEX IF NOT EXISTS idx_follows_created_at ON public.follows(created_at DESC);

-- ==========================================
-- CREATE FUNCTIONS FOR COUNT UPDATES
-- ==========================================

-- Function to update follow counts when relationships change
CREATE OR REPLACE FUNCTION update_follow_counts()
RETURNS TRIGGER AS $$
BEGIN
    -- Handle INSERT (new follow relationship)
    IF TG_OP = 'INSERT' THEN
        -- Increment following_count for the follower
        UPDATE public.profiles 
        SET following_count = following_count + 1 
        WHERE user_id = NEW.follower_id;
        
        -- Increment followers_count for the user being followed
        UPDATE public.profiles 
        SET followers_count = followers_count + 1 
        WHERE user_id = NEW.following_id;
        
        RETURN NEW;
    END IF;
    
    -- Handle DELETE (unfollowing)
    IF TG_OP = 'DELETE' THEN
        -- Decrement following_count for the follower
        UPDATE public.profiles 
        SET following_count = GREATEST(following_count - 1, 0) 
        WHERE user_id = OLD.follower_id;
        
        -- Decrement followers_count for the user being unfollowed
        UPDATE public.profiles 
        SET followers_count = GREATEST(followers_count - 1, 0) 
        WHERE user_id = OLD.following_id;
        
        RETURN OLD;
    END IF;
    
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add comment to function
COMMENT ON FUNCTION update_follow_counts() IS 'Automatically updates follower and following counts in profiles table when follow relationships change';

-- ==========================================
-- CREATE TRIGGERS
-- ==========================================

-- Create trigger to automatically update counts when follows table changes
DROP TRIGGER IF EXISTS trigger_update_follow_counts ON public.follows;
CREATE TRIGGER trigger_update_follow_counts
    AFTER INSERT OR DELETE ON public.follows
    FOR EACH ROW
    EXECUTE FUNCTION update_follow_counts();

-- ==========================================
-- CREATE RLS POLICIES
-- ==========================================

-- Enable RLS on follows table
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;

-- Policy: Anyone can read follow relationships (public information)
CREATE POLICY "Follow relationships are publicly readable" ON public.follows
    FOR SELECT USING (true);

-- Policy: Users can only create follows for themselves
CREATE POLICY "Users can create follows for themselves" ON public.follows
    FOR INSERT WITH CHECK (auth.uid() = follower_id);

-- Policy: Users can only delete their own follows
CREATE POLICY "Users can delete their own follows" ON public.follows
    FOR DELETE USING (auth.uid() = follower_id);

-- ==========================================
-- UTILITY FUNCTIONS
-- ==========================================

-- Function to check if a user follows another user
CREATE OR REPLACE FUNCTION is_following(p_follower_id UUID, p_following_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.follows 
        WHERE follower_id = p_follower_id 
        AND following_id = p_following_id
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION is_following(UUID, UUID) IS 'Check if one user follows another user';

-- Function to get mutual follows (users who follow each other)
CREATE OR REPLACE FUNCTION get_mutual_follows(p_user_id UUID)
RETURNS TABLE (
    mutual_user_id UUID,
    mutual_username TEXT,
    mutual_full_name TEXT,
    mutual_avatar_url TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.user_id,
        p.username,
        p.full_name,
        p.avatar_url
    FROM public.profiles p
    WHERE p.user_id IN (
        -- Users that p_user_id follows who also follow p_user_id back
        SELECT f1.following_id
        FROM public.follows f1
        WHERE f1.follower_id = p_user_id
        AND EXISTS (
            SELECT 1 FROM public.follows f2
            WHERE f2.follower_id = f1.following_id
            AND f2.following_id = p_user_id
        )
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_mutual_follows(UUID) IS 'Get users who mutually follow each other with a given user';

-- ==========================================
-- RECALCULATE EXISTING COUNTS
-- ==========================================

-- Function to recalculate and fix follow counts (useful for maintenance)
CREATE OR REPLACE FUNCTION recalculate_follow_counts()
RETURNS VOID AS $$
BEGIN
    -- Update following_count for all profiles
    UPDATE public.profiles 
    SET following_count = (
        SELECT COUNT(*) 
        FROM public.follows 
        WHERE follower_id = profiles.user_id
    );
    
    -- Update followers_count for all profiles
    UPDATE public.profiles 
    SET followers_count = (
        SELECT COUNT(*) 
        FROM public.follows 
        WHERE following_id = profiles.user_id
    );
    
    RAISE NOTICE 'Follow counts recalculated successfully';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION recalculate_follow_counts() IS 'Recalculate all follow counts in profiles table (maintenance function)';

-- ==========================================
-- GRANTS AND PERMISSIONS
-- ==========================================

-- Grant necessary permissions for authenticated users
GRANT SELECT, INSERT, DELETE ON public.follows TO authenticated;
GRANT USAGE ON SEQUENCE follows_id_seq TO authenticated;

-- Grant execute permissions on utility functions
GRANT EXECUTE ON FUNCTION is_following(UUID, UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION get_mutual_follows(UUID) TO authenticated;

-- Grant execute permission on maintenance function to service role only
GRANT EXECUTE ON FUNCTION recalculate_follow_counts() TO service_role;

-- ==========================================
-- FINAL VERIFICATION
-- ==========================================

-- Verify the migration was successful
DO $$
BEGIN
    -- Check if follows table exists with correct structure
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'follows'
    ) THEN
        RAISE EXCEPTION 'follows table was not created successfully';
    END IF;
    
    -- Check if new columns exist in profiles table
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'profiles' 
        AND column_name = 'followers_count'
    ) THEN
        RAISE EXCEPTION 'followers_count column was not added to profiles table';
    END IF;
    
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'profiles' 
        AND column_name = 'following_count'
    ) THEN
        RAISE EXCEPTION 'following_count column was not added to profiles table';
    END IF;
    
    RAISE NOTICE 'ConcertCritic follow system migration completed successfully!';
END $$;