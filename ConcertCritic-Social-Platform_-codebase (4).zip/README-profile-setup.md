# 🎵 Profile Editing Setup Guide

Complete setup instructions for implementing user profile editing functionality in ConcertCritic.

## 📋 Overview

This implementation provides a complete profile editing system that allows users to:

- ✅ Upload and manage profile avatars with drag & drop
- ✅ Edit personal information (username, bio, location)  
- ✅ View real-time form validation
- ✅ Experience smooth UI interactions with loading states
- ✅ Secure file uploads with proper validation

## 🗄️ Database Setup

### 1. Run the Migration

Execute the `supabase-profile-updates-migration.sql` file in your Supabase dashboard:

```sql
-- This migration adds the location field and sets up avatar storage
BEGIN;

-- Add location field to profiles table
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS location TEXT;

-- Create avatars storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'avatars',
  'avatars', 
  true,
  5242880, -- 5MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
)
ON CONFLICT (id) DO NOTHING;

COMMIT;
```

### 2. Verify Database Schema

Ensure your profiles table has these columns:
- `id` (UUID, Primary Key)
- `user_id` (UUID, Foreign Key to auth.users)
- `username` (VARCHAR, Unique)
- `bio` (TEXT, Nullable)
- `location` (TEXT, Nullable) 
- `avatar_url` (TEXT, Nullable)
- `created_at` (TIMESTAMP)
- `updated_at` (TIMESTAMP)

## 🔧 Supabase Storage Setup

### 1. Create Storage Bucket

In your Supabase dashboard, navigate to **Storage** and create a new bucket:

- **Bucket Name**: `avatars`
- **Public**: `true` (enabled)
- **File Size Limit**: `5MB`
- **Allowed MIME Types**: `image/jpeg, image/png, image/webp, image/gif`

### 2. Configure RLS Policies

Set up Row Level Security policies for secure file access:

```sql
-- Allow authenticated users to upload their own avatars
CREATE POLICY "Users can upload their own avatars"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow public read access to all avatar images
CREATE POLICY "Public read access for avatars"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'avatars');

-- Allow users to update their own avatar files
CREATE POLICY "Users can update their own avatars"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'avatars'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow users to delete their own avatar files
CREATE POLICY "Users can delete their own avatars"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'avatars'
  AND auth.uid()::text = (storage.foldername(name))[1]
);
```

## ✨ Features Implemented

### User Interface Components

- **EditProfileModal**: Main modal dialog for profile editing
- **AvatarUpload**: Specialized component for avatar file uploads
- **ProfileAnalytics**: Updated profile page with edit functionality
- **Form Validation**: Real-time validation with clear error messages
- **Loading States**: Progress indicators and smooth transitions

### Backend Functionality

- **Secure File Upload**: 5MB limit with image type validation  
- **Database Integration**: Profile creation and updates via Supabase
- **Storage Management**: Automatic file organization by user ID
- **Error Handling**: Comprehensive error catching and user feedback
- **Profile State Management**: Real-time profile data synchronization

## 🎯 How to Use

### For Users

1. **Access Profile Editor**:
   - Navigate to the Profile tab in the app
   - Click "Edit Profile" button (or "Create Profile" for new users)

2. **Upload Avatar**:
   - Click on the avatar area or drag & drop an image file
   - Supported formats: JPEG, PNG, WebP, GIF (max 5MB)
   - Preview appears instantly before saving

3. **Edit Information**:
   - **Username**: 3-20 characters, letters/numbers/underscores only
   - **Bio**: Optional, up to 500 characters
   - **Location**: Optional, free text field
   - **Avatar**: Upload file or paste image URL

4. **Save Changes**:
   - Click "Save Changes" or "Create Profile"
   - Success message appears upon completion
   - Profile updates immediately across the app

### Form Validation Rules

| Field | Requirements | Notes |
|-------|-------------|-------|
| Username | Required, 3-20 chars, alphanumeric + underscore | Must be unique |
| Bio | Optional, max 500 characters | Supports all text |
| Location | Optional, free text | City, country, etc. |
| Avatar | Image files only, max 5MB | Auto-optimized |

## 🏗️ Technical Architecture

### Component Structure

```
src/components/concert-critic/
├── edit-profile-modal.tsx       # Main editing interface
├── profile-analytics.tsx        # Profile page with edit button
└── avatar-upload.tsx            # Specialized upload component

src/lib/
├── auth-context.tsx             # Updated with profile management
└── supabase.ts                  # Database client
```

### State Management

- **React Hooks**: `useState`, `useEffect`, `useCallback` for local state
- **Auth Context**: Global user and profile state management
- **Form State**: Real-time validation and error handling
- **Upload State**: Progress tracking and status management

### File Upload Flow

1. User selects image file (drag & drop or file picker)
2. Client-side validation (size, type, format)
3. Generate unique filename: `{user_id}/avatar-{timestamp}.{ext}`
4. Upload to Supabase Storage with progress tracking
5. Update profile record with new avatar URL
6. Refresh UI with new avatar and success notification

## 🛡️ Security Features

- **RLS Policies**: Users can only access their own files
- **File Validation**: Size and type restrictions enforced
- **Authentication**: All operations require valid user session
- **Secure URLs**: Public read access for avatars, private write access
- **Error Handling**: No sensitive data exposed in error messages

## 🔧 Troubleshooting

### Common Issues

**❌ Upload fails with "Permission denied"**
- Check RLS policies are correctly configured
- Verify user is authenticated
- Ensure bucket permissions are set to public for reading

**❌ Images don't display**  
- Check storage bucket is public
- Verify avatar URL format is correct
- Test direct image URL access

**❌ Form validation errors persist**
- Clear browser cache
- Check browser console for JavaScript errors
- Verify all required fields are filled

### Debug Commands

```sql
-- Check storage bucket configuration
SELECT * FROM storage.buckets WHERE name = 'avatars';

-- Verify user profile exists
SELECT * FROM profiles WHERE user_id = auth.uid();

-- List uploaded avatar files
SELECT * FROM storage.objects WHERE bucket_id = 'avatars';

-- Check RLS policies
SELECT * FROM pg_policies WHERE tablename = 'objects';
```

### Performance Tips

- Enable image optimization in Supabase Storage settings
- Implement lazy loading for avatar images in lists  
- Use appropriate image formats (WebP for best compression)
- Consider implementing client-side image compression
- Cache profile data to reduce database queries

## 🚀 Deployment Checklist

- [ ] Database migration executed successfully
- [ ] Storage bucket created with correct permissions
- [ ] RLS policies configured and tested
- [ ] Avatar upload functionality tested end-to-end
- [ ] Form validation working on all fields
- [ ] Error handling tested with invalid inputs
- [ ] Mobile responsiveness verified
- [ ] Performance tested with large image files

## 📝 Next Steps

Consider implementing these additional features:

- **Image Cropping**: Allow users to crop/resize uploaded images
- **Multiple Images**: Support for cover photos or image galleries
- **Social Features**: Profile following and friend connections
- **Privacy Settings**: Control profile visibility and information sharing
- **Activity Tracking**: Log profile changes and user activity

---

## 🎉 Success!

Your profile editing system is now fully implemented and ready for users! The combination of secure file uploads, real-time validation, and smooth user experience makes this a production-ready feature.

For additional support or feature requests, please refer to the main project documentation.